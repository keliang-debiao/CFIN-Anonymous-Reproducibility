# CFIN Reproducibility Package

This anonymous repository contains the executable workflow for the manuscript on Cross-Feature Interaction Networks (CFIN) for student dropout prediction. It covers data registration, leakage-safe preprocessing, fixed train/test partitions, model fitting, ten-seed evaluation, statistical comparison, feature attribution, efficiency measurement, and manuscript-table generation.

## Repository status

- `manuscript_targets/` contains values transcribed from the revised manuscript. These files are reference targets, not outputs from the verification run bundled here.
- `logs/pipeline_verification.log` is produced by executing the repository's fast validation workflow. It confirms data-flow, metric, threshold, and statistical-test behavior; it is not a substitute for the full study runs.
- Full-study outputs are created under `results/` after the two source datasets are registered and the requested commands are executed.
- No author names, affiliations, e-mail addresses, grant identifiers, local user paths, credentials, or repository history are included.

## System requirements

- Linux or Windows Subsystem for Linux
- Python 3.11
- NVIDIA GPU with CUDA support for the neural-model timing protocol; CPU execution is supported for functional checks
- Approximately 16 GB RAM and 10 GB free disk space

## Installation

Using Conda:

```bash
conda env create -f environment.yml
conda activate cfin-repro
pip install -e .
```

Using a virtual environment:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
```

## Data registration

The UCI dataset can be retrieved programmatically. The INELS source requires acceptance of the hosting platform's terms and, when required by that platform, an authenticated account.

```bash
python scripts/fetch_data.py --dataset uci
python scripts/fetch_data.py --dataset inels
```

If the INELS CSV was obtained separately, register it directly:

```bash
python scripts/register_data.py --dataset inels --source /absolute/path/to/studentDropIndia_20161215.csv
```

Data provenance, expected record counts, target distributions, and validation checks are specified in [DATA.md](DATA.md). Source data are not redistributed by this archive.

## Fast verification

```bash
python scripts/verify_pipeline.py
python scripts/run_tests_with_log.py
python scripts/check_repository.py
```

The first command writes `logs/pipeline_verification.log`. The second checks anonymity, prohibited terms, configuration completeness, import syntax, and the separation between manuscript targets and generated outputs.

## Full reproduction

Run the complete ten-seed protocol after both datasets are registered:

```bash
python scripts/run_study.py --stage tune
python scripts/run_study.py --stage train
python scripts/run_study.py --stage horizons
python scripts/run_study.py --stage sensitivity
python scripts/run_study.py --stage ablation
python scripts/run_study.py --stage statistics
python scripts/run_study.py --stage attribution
python scripts/run_study.py --stage efficiency
python scripts/run_study.py --stage report
```

To execute only one dataset or one model:

```bash
cfin run --dataset inels --model cfin --seed 11
cfin run --dataset uci --model ft_transformer --seed 11
```

All fixed seeds, model settings, feature horizons, grouping rules, imputation decisions, and evaluation conventions are stored under `configs/`. Full runs write resolved configurations, package versions, data hashes, predictions, checkpoints, metrics, and event logs beneath `results/`.

## Primary outputs

- `results/runs/<dataset>/<model>/<seed>/metrics.json`
- `results/runs/<dataset>/<model>/<seed>/predictions.csv`
- `results/runs/<dataset>/<model>/<seed>/resolved_config.yaml`
- `results/statistics/pairwise_tests.csv`
- `results/attribution/feature_attribution.csv`
- `results/attribution/group_attribution.csv`
- `results/efficiency/efficiency.csv`
- `results/tables/` manuscript-ready CSV tables

## Integrity rule

The workflow never copies values from `manuscript_targets/` into generated result directories. Agreement is assessed by `cfin compare-targets`, which reports differences without modifying either side.

## License

Repository code is released under the MIT License. Each dataset remains subject to the terms stated by its original provider.
