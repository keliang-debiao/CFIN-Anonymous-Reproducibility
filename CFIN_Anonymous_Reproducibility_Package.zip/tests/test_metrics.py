import numpy as np

from cfin.metrics import classification_metrics, select_binary_threshold


def test_binary_metrics_are_bounded():
    y = np.array([0, 0, 1, 1])
    probability = np.array([[0.9, 0.1], [0.7, 0.3], [0.4, 0.6], [0.1, 0.9]])
    result = classification_metrics(y, probability, ["continue", "drop"], 0.5)
    for field in ("accuracy", "macro_precision", "macro_recall", "macro_f1", "macro_ovr_auc"):
        assert 0.0 <= result[field] <= 1.0


def test_threshold_tie_uses_lowest_value():
    y = np.array([0, 1])
    score = np.array([0.1, 0.9])
    threshold, value = select_binary_threshold(y, score, np.array([0.2, 0.3, 0.4]))
    assert threshold == 0.2
    assert value == 1.0
