from collections import OrderedDict

import pytest

torch = pytest.importorskip("torch")

from cfin.model import CFIN, WeightedFocalLoss


def test_forward_shape_and_loss():
    settings = {
        "token_dimension": 16,
        "dropout": 0.1,
        "group_attention_heads": 4,
        "group_feedforward_dimension": 32,
        "group_encoder_layers": 1,
        "context_attention_heads": 4,
        "context_feedforward_dimension": 32,
        "context_encoder_layers": 2,
        "head_hidden_dimension": 8,
    }
    model = CFIN(3, [4, 5], OrderedDict([("academic", [0, 1, 2]), ("context", [3, 4])]), 2, settings)
    numeric = torch.randn(7, 3)
    categorical = torch.stack([torch.randint(0, 4, (7,)), torch.randint(0, 5, (7,))], dim=1)
    logits = model(numeric, categorical)
    assert logits.shape == (7, 2)
    loss = WeightedFocalLoss([0.5, 2.0], 2.0)(logits, torch.randint(0, 2, (7,)))
    assert torch.isfinite(loss)
