import numpy as np

from cfin.statistics import exact_mcnemar, holm_adjust, paired_delong


def test_mcnemar_symmetry():
    y = np.array([0, 0, 1, 1, 1, 0])
    a = np.array([0, 1, 1, 0, 1, 0])
    b = np.array([0, 0, 0, 1, 1, 0])
    forward = exact_mcnemar(y, a, b)
    reverse = exact_mcnemar(y, b, a)
    assert forward["p_value"] == reverse["p_value"]


def test_holm_is_monotone_in_rank_order():
    raw = [0.04, 0.01, 0.03]
    adjusted = holm_adjust(raw)
    order = np.argsort(raw)
    assert np.all(np.diff(np.asarray(adjusted)[order]) >= 0)


def test_delong_prefers_better_scores():
    y = np.array([0, 0, 0, 1, 1, 1])
    strong = np.array([0.1, 0.2, 0.3, 0.7, 0.8, 0.9])
    weak = np.array([0.2, 0.5, 0.4, 0.6, 0.55, 0.7])
    result = paired_delong(y, strong, weak)
    assert result["difference"] >= 0
    assert 0 <= result["p_value"] <= 1
