import numpy as np
import pandas as pd

from cfin.config import load_config
from cfin.data import NeuralPreprocessor, clean_frame, fixed_partition, normalize_name


def test_name_normalization():
    assert normalize_name("Mother's qualification") == "mothers_qualification"
    assert normalize_name("Curricular units 1st sem (approved)") == "curricular_units_1st_sem_approved"


def test_correction_occurs_before_partition():
    config = load_config("inels")
    count = 100
    labels = np.array(["continue"] * 80 + ["drop"] * 20)
    frame = pd.DataFrame(
        {
            "continue_drop": labels,
            "mathematics_marks": np.linspace(-0.2, 1.2, count),
            "english_marks": np.linspace(0.0, 1.0, count),
            "science_marks": np.linspace(-0.2, 1.2, count),
            "total_toilets": [np.nan] + [3.0] * 99,
            "establishment_year": [2020.0] + [2000.0] * 99,
            "gender": ["F", "M"] * 50,
            "guardian": ["mother"] * count,
        }
    )
    cleaned = clean_frame(frame, config)
    assert cleaned["establishment_year"].isna().sum() == 1
    assert cleaned["mathematics_marks"].between(0.0, 1.0).all()
    partition = fixed_partition(cleaned, config)
    fields = partition.train.drop(columns=["continue_drop", "science_marks"])
    processor = NeuralPreprocessor(config).fit(fields)
    numeric, categorical, _ = processor.transform(fields)
    assert np.isfinite(numeric).all()
    assert len(numeric) == 80
