# Reproduction Protocol

## Fixed design

The train/test partition is created once per dataset with seed 2025 and is shared across all models. Hyperparameter selection uses only the training portion through stratified five-fold cross-validation. The final settings are evaluated over seeds `11, 23, 37, 47, 59, 71, 83, 97, 109, 127` on the unchanged test partition.

The tuning objective is mean validation macro-F1 over 50 Optuna trials for each model. No test-set metric is available to the tuning process. Study databases, selected settings, fold assignments, and trial tables are persisted in `results/tuning/`.

## Imbalance handling

CFIN and the neural baselines use inverse-frequency class weights computed from the training partition. CFIN uses focal loss with gamma 2.0 in the main analysis. The expected weights are `[0.524725, 10.611111]` for INELS and `[1.037526, 1.857743, 0.667610]` for UCI in the class order stored by each dataset configuration. Conventional baselines use their native class-weight interface when available. No oversampling is used.

For INELS, the decision threshold is selected independently within each training run from `0.05` to `0.95` in increments of `0.01`, maximizing validation macro-F1. The selected threshold is then frozen for test evaluation. UCI predictions use the largest class probability.

## Metrics

Every run reports accuracy, macro precision, macro recall, macro-F1, and macro one-vs-rest ROC-AUC. Class-specific metrics and confusion matrices are retained. Aggregation reports the mean and standard deviation across ten seeds.

## Statistical inference

CFIN is compared with FT-Transformer using paired predictions from matched seeds.

- Accuracy: exact McNemar test.
- INELS ROC-AUC: paired DeLong test.
- UCI macro ROC-AUC and macro-F1: 10,000 paired stratified bootstrap replicates with the pre-specified directional alternative that CFIN improves on FT-Transformer.
- Family-wise control: Holm adjustment within each dataset.

Bootstrap random states are derived from the evaluation seed and recorded in each test row. Confidence intervals use the 2.5th and 97.5th percentiles of the paired difference distribution.

## Attribution

Permutation SHAP uses a 256-record stratified background drawn from the training partition with seed 2025. INELS uses 1,000 stratified test records and explains the dropout probability. UCI uses all 885 test records and explains the dropout probability. Feature importance is the mean absolute SHAP value. Group importance is the sum of member-feature importance followed by normalization to 100 percent.

## Efficiency

GPU timing uses a single NVIDIA RTX 4090, 100 warm-up passes, and 1,000 timed passes at batch sizes 1 and 256. CUDA synchronization occurs immediately before and after every timed pass. The report uses the median across ten trained seeds. Training time covers model optimization and early stopping, but excludes data download, tuning, attribution, and report generation.

## Result provenance

Every run directory includes a resolved configuration, input digest, package inventory, hardware record, run log, predictions, metrics, and model state. Generated tables are derived only from these run directories. Manuscript values remain in a separate read-only reference directory and are never treated as generated evidence.
