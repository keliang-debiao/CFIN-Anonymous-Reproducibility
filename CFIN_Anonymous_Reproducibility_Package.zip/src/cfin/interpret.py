from __future__ import annotations

from collections import OrderedDict
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import train_test_split

from .config import ROOT, load_config, load_yaml
from .data import clean_frame, encode_partition, fixed_partition, read_dataset
from .model import build_neural_model
from .train import predict_probabilities


def _groups(labels: list[str]) -> OrderedDict[str, list[int]]:
    result: OrderedDict[str, list[int]] = OrderedDict()
    for index, label in enumerate(labels):
        result.setdefault(label, []).append(index)
    return result


def run_attribution(dataset: str, seed: int, output: Path, root: Path = ROOT) -> tuple[pd.DataFrame, pd.DataFrame]:
    import shap

    config = load_config(dataset)
    horizon = "full_record" if dataset == "inels" else "t2_second_semester"
    partition = fixed_partition(clean_frame(read_dataset(config, root), config), config)
    encoded = encode_partition(partition, config, horizon)
    groups = _groups(encoded.feature_groups)
    run_dir = root / "results" / "runs" / dataset / "cfin" / str(seed)
    resolved = load_yaml(run_dir / "resolved_config.yaml")
    settings = {**resolved["architecture"], **resolved["training"]}
    model = build_neural_model(
        "cfin",
        encoded.x_num_train.shape[1],
        encoded.category_cardinalities,
        groups,
        len(partition.class_names),
        settings,
    )
    state = torch.load(run_dir / "model.pt", map_location="cpu", weights_only=True)
    model.load_state_dict(state)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    train_matrix = np.column_stack([encoded.x_num_train, encoded.x_cat_train.astype(np.float32)])
    test_matrix = np.column_stack([encoded.x_num_test, encoded.x_cat_test.astype(np.float32)])
    background_indices, _ = train_test_split(
        np.arange(len(encoded.y_train)),
        train_size=config["attribution"]["background_size"],
        random_state=config["attribution"]["random_seed"],
        stratify=encoded.y_train,
    )
    if dataset == "inels":
        _, evaluation_indices = train_test_split(
            np.arange(len(encoded.y_test)),
            test_size=config["attribution"]["inels_evaluation_size"],
            random_state=config["attribution"]["random_seed"],
            stratify=encoded.y_test,
        )
    else:
        evaluation_indices = np.arange(len(encoded.y_test))
    n_numeric = encoded.x_num_train.shape[1]

    def prediction_function(matrix: np.ndarray) -> np.ndarray:
        numeric = matrix[:, :n_numeric].astype(np.float32)
        categorical = np.rint(matrix[:, n_numeric:]).astype(np.int64)
        return predict_probabilities(model, numeric, categorical, 256, device)

    explainer = shap.PermutationExplainer(
        prediction_function,
        train_matrix[background_indices],
        seed=config["attribution"]["random_seed"],
    )
    explanation = explainer(
        test_matrix[evaluation_indices],
        max_evals=2 * test_matrix.shape[1] + 1,
    )
    dropout_index = partition.class_names.index("dropout" if dataset == "uci" else "drop")
    values = explanation.values
    if values.ndim == 3:
        values = values[:, :, dropout_index]
    importance = np.abs(values).mean(axis=0)
    feature_frame = pd.DataFrame(
        {
            "dataset": dataset,
            "seed": seed,
            "feature": encoded.feature_fields,
            "group": encoded.feature_groups,
            "mean_absolute_shap": importance,
        }
    ).sort_values("mean_absolute_shap", ascending=False)
    group_frame = feature_frame.groupby(["dataset", "seed", "group"], as_index=False)["mean_absolute_shap"].sum()
    group_frame["percent"] = 100.0 * group_frame["mean_absolute_shap"] / group_frame["mean_absolute_shap"].sum()
    output.mkdir(parents=True, exist_ok=True)
    feature_frame.to_csv(output / f"{dataset}_seed_{seed}_feature_attribution.csv", index=False)
    group_frame.to_csv(output / f"{dataset}_seed_{seed}_group_attribution.csv", index=False)
    return feature_frame, group_frame
