from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Any

import numpy as np
import optuna
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold

from .baselines import build_baseline
from .config import ROOT, load_config, load_yaml
from .data import NeuralPreprocessor, baseline_encode_frames, clean_frame, fixed_partition, read_dataset, select_horizon
from .groups import field_group
from .model import build_neural_model
from .train import fit_neural, predict_probabilities
from .utils import set_global_seed, write_json


def _suggest(trial: optuna.Trial, space: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, definition in space.items():
        kind = definition["type"]
        if kind == "categorical":
            result[name] = trial.suggest_categorical(name, definition["choices"])
        elif kind == "integer":
            result[name] = trial.suggest_int(name, definition["low"], definition["high"], step=definition.get("step", 1))
        elif kind == "float":
            result[name] = trial.suggest_float(name, definition["low"], definition["high"])
        elif kind == "float_log":
            result[name] = trial.suggest_float(name, definition["low"], definition["high"], log=True)
        elif kind == "conditional_solver":
            result[name] = trial.suggest_categorical(name, definition["choices"])
        else:
            raise ValueError(f"Unknown tuning setting: {kind}")
    if result.get("penalty") == "l1" and result.get("solver") not in {"liblinear", "saga"}:
        result["solver"] = "saga"
    if result.get("max_features") == "all":
        result["max_features"] = 1.0
    if result.get("max_features") == "half":
        result["max_features"] = 0.5
    return result


def _groups(labels: list[str]) -> OrderedDict[str, list[int]]:
    result: OrderedDict[str, list[int]] = OrderedDict()
    for index, label in enumerate(labels):
        result.setdefault(label, []).append(index)
    return result


def tune_model(dataset: str, model_name: str, root: Path = ROOT) -> Path:
    config = load_config(dataset)
    tuning = load_yaml(root / "configs" / "tuning.yaml")["models"][model_name]
    horizon = "full_record" if dataset == "inels" else "t2_second_semester"
    partition = fixed_partition(clean_frame(read_dataset(config, root), config), config)
    folds = StratifiedKFold(
        n_splits=int(config["protocol"]["cv_folds"]), shuffle=True, random_state=config["protocol"]["split_seed"]
    )
    raw_train = select_horizon(partition.train, config, horizon)
    fold_indices = list(folds.split(raw_train, partition.y_train))
    output = root / "results" / "tuning" / dataset / model_name
    output.mkdir(parents=True, exist_ok=True)
    storage = f"sqlite:///{(output / 'study.sqlite').as_posix()}"

    if model_name in {"logistic_regression", "random_forest", "xgboost"}:
        prepared_folds = []
        for fold_train, fold_valid in fold_indices:
            x_train, x_valid, _ = baseline_encode_frames(
                raw_train.iloc[fold_train], raw_train.iloc[fold_valid], config
            )
            prepared_folds.append((fold_train, fold_valid, x_train, x_valid))

        def objective(trial: optuna.Trial) -> float:
            params = _suggest(trial, tuning)
            scores = []
            for fold_train, fold_valid, x_train, x_valid in prepared_folds:
                model = build_baseline(model_name, trial.number, len(partition.class_names), params)
                fit_arguments: dict[str, Any] = {}
                if model_name == "xgboost":
                    from sklearn.utils.class_weight import compute_sample_weight

                    fit_arguments["sample_weight"] = compute_sample_weight("balanced", partition.y_train[fold_train])
                model.fit(x_train, partition.y_train[fold_train], **fit_arguments)
                prediction = model.predict(x_valid)
                scores.append(f1_score(partition.y_train[fold_valid], prediction, average="macro"))
            return float(np.mean(scores))

    elif model_name == "tabnet":
        import torch
        from pytorch_tabnet.tab_model import TabNetClassifier

        prepared_folds = []
        for fold_train, fold_valid in fold_indices:
            x_train, x_valid, _ = baseline_encode_frames(
                raw_train.iloc[fold_train], raw_train.iloc[fold_valid], config
            )
            if hasattr(x_train, "toarray"):
                x_train = x_train.toarray()
                x_valid = x_valid.toarray()
            prepared_folds.append(
                (fold_train, fold_valid, np.asarray(x_train, dtype=np.float32), np.asarray(x_valid, dtype=np.float32))
            )

        def objective(trial: optuna.Trial) -> float:
            params = _suggest(trial, tuning)
            scores = []
            for fold_index, (fold_train, fold_valid, x_train, x_valid) in enumerate(prepared_folds):
                fold_seed = 1000 * trial.number + fold_index
                model = TabNetClassifier(
                    **params,
                    optimizer_fn=torch.optim.AdamW,
                    optimizer_params={"lr": config["training"]["learning_rate"], "weight_decay": config["training"]["weight_decay"]},
                    seed=fold_seed,
                    verbose=0,
                )
                model.fit(
                    x_train,
                    partition.y_train[fold_train],
                    eval_set=[(x_valid, partition.y_train[fold_valid])],
                    eval_name=["validation"],
                    eval_metric=["logloss"],
                    max_epochs=int(config["training"]["maximum_epochs"]),
                    patience=int(config["training"]["early_stopping_patience"]),
                    batch_size=int(config["training"]["batch_size"]),
                    virtual_batch_size=128,
                    weights=1,
                    num_workers=0,
                    drop_last=False,
                )
                scores.append(f1_score(partition.y_train[fold_valid], model.predict(x_valid), average="macro"))
            return float(np.mean(scores))

    elif model_name in {"cfin", "ft_transformer"}:
        prepared_folds = []
        for fold_train, fold_valid in fold_indices:
            processor = NeuralPreprocessor(config).fit(raw_train.iloc[fold_train])
            x_num_train, x_cat_train, numeric_fields = processor.transform(raw_train.iloc[fold_train])
            x_num_valid, x_cat_valid, _ = processor.transform(raw_train.iloc[fold_valid])
            feature_fields = numeric_fields + processor.categorical_fields
            group_labels = [field_group(field.removesuffix("_missing"), config) for field in feature_fields]
            prepared_folds.append(
                (
                    fold_train,
                    fold_valid,
                    x_num_train,
                    x_cat_train,
                    x_num_valid,
                    x_cat_valid,
                    processor.category_cardinalities,
                    _groups(group_labels),
                )
            )

        def objective(trial: optuna.Trial) -> float:
            params = _suggest(trial, tuning)
            scores = []
            for fold_index, prepared in enumerate(prepared_folds):
                fold_train, fold_valid, x_num_train, x_cat_train, x_num_valid, x_cat_valid, cardinalities, groups = prepared
                fold_seed = 1000 * trial.number + fold_index
                set_global_seed(fold_seed)
                settings = {**config["architecture"], **config["training"], **params}
                fold_config = {**config, "architecture": {**config["architecture"], **params}, "training": {**config["training"], **params}}
                model = build_neural_model(
                    model_name,
                    x_num_train.shape[1],
                    cardinalities,
                    groups,
                    len(partition.class_names),
                    settings,
                )
                fitted = fit_neural(
                    model,
                    x_num_train,
                    x_cat_train,
                    partition.y_train[fold_train],
                    config["class_weights"],
                    fold_config,
                    fold_seed,
                )
                device = next(fitted.model.parameters()).device
                probability = predict_probabilities(
                    fitted.model,
                    x_num_valid,
                    x_cat_valid,
                    int(config["training"]["batch_size"]),
                    device,
                )
                if probability.shape[1] == 2 and fitted.threshold is not None:
                    prediction = (probability[:, 1] >= fitted.threshold).astype(int)
                else:
                    prediction = probability.argmax(axis=1)
                scores.append(f1_score(partition.y_train[fold_valid], prediction, average="macro"))
            return float(np.mean(scores))

    else:
        raise ValueError(f"Tuning is not available for {model_name}")
    study = optuna.create_study(
        study_name=f"{dataset}_{model_name}",
        direction="maximize",
        storage=storage,
        load_if_exists=True,
        sampler=optuna.samplers.TPESampler(seed=config["protocol"]["split_seed"]),
    )
    completed_trials = sum(
        trial.state == optuna.trial.TrialState.COMPLETE for trial in study.trials
    )
    remaining = max(0, int(config["protocol"]["tuning_trials"]) - completed_trials)
    if remaining:
        study.optimize(objective, n_trials=remaining)
    study.trials_dataframe().to_csv(output / "trials.csv", index=False)
    best_params = dict(study.best_params)
    if best_params.get("max_features") == "all":
        best_params["max_features"] = 1.0
    elif best_params.get("max_features") == "half":
        best_params["max_features"] = 0.5
    write_json({"best_value": study.best_value, "best_params": best_params}, output / "best.json")
    return output
