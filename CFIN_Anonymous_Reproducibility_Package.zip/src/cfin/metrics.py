from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    precision_recall_fscore_support,
    roc_auc_score,
)


def select_binary_threshold(y_true: np.ndarray, positive_probability: np.ndarray, grid: np.ndarray) -> tuple[float, float]:
    best_threshold = float(grid[0])
    best_score = -np.inf
    for threshold in grid:
        prediction = (positive_probability >= threshold).astype(int)
        score = precision_recall_fscore_support(
            y_true, prediction, average="macro", zero_division=0
        )[2]
        if score > best_score + 1e-12:
            best_score = float(score)
            best_threshold = float(threshold)
    return best_threshold, best_score


def classification_metrics(
    y_true: np.ndarray,
    probabilities: np.ndarray,
    class_names: list[str],
    threshold: float | None = None,
) -> dict[str, Any]:
    if probabilities.shape[1] == 2 and threshold is not None:
        prediction = (probabilities[:, 1] >= threshold).astype(int)
    else:
        prediction = probabilities.argmax(axis=1)
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, prediction, labels=np.arange(len(class_names)), zero_division=0
    )
    macro_precision, macro_recall, macro_f1, _ = precision_recall_fscore_support(
        y_true, prediction, average="macro", zero_division=0
    )
    if len(class_names) == 2:
        auc = roc_auc_score(y_true, probabilities[:, 1])
    else:
        auc = roc_auc_score(y_true, probabilities, multi_class="ovr", average="macro")
    return {
        "accuracy": float(accuracy_score(y_true, prediction)),
        "macro_precision": float(macro_precision),
        "macro_recall": float(macro_recall),
        "macro_f1": float(macro_f1),
        "macro_ovr_auc": float(auc),
        "threshold": threshold,
        "confusion_matrix": confusion_matrix(y_true, prediction).tolist(),
        "per_class": {
            class_names[index]: {
                "precision": float(precision[index]),
                "recall": float(recall[index]),
                "f1": float(f1[index]),
                "support": int(support[index]),
            }
            for index in range(len(class_names))
        },
    }
