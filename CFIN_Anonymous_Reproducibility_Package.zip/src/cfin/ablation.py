from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from sklearn.cluster import AgglomerativeClustering

from .config import ROOT, load_config, save_yaml
from .data import clean_frame, encode_partition, fixed_partition, read_dataset
from .groups import random_groups
from .metrics import classification_metrics
from .model import build_neural_model
from .train import fit_neural, predict_probabilities
from .utils import set_global_seed, write_json


CONDITIONS = [
    "full_cfin",
    "without_inter_group_context",
    "flat_transformer",
    "weighted_cross_entropy",
    "unweighted_cross_entropy",
    "random_grouping",
    "data_driven_grouping",
    "alternative_four_domain_grouping",
]


def semantic_groups(labels: list[str]) -> OrderedDict[str, list[int]]:
    result: OrderedDict[str, list[int]] = OrderedDict()
    for index, label in enumerate(labels):
        result.setdefault(label, []).append(index)
    return result


def correlation_groups(matrix: np.ndarray, count: int = 4) -> OrderedDict[str, list[int]]:
    correlation = np.corrcoef(matrix, rowvar=False)
    correlation = np.nan_to_num(correlation, nan=0.0, posinf=0.0, neginf=0.0)
    distance = 1.0 - np.abs(correlation)
    np.fill_diagonal(distance, 0.0)
    labels = AgglomerativeClustering(n_clusters=count, metric="precomputed", linkage="average").fit_predict(distance)
    result: OrderedDict[str, list[int]] = OrderedDict()
    for label in range(count):
        result[f"cluster_{label + 1}"] = np.flatnonzero(labels == label).tolist()
    return result


def alternative_groups(fields: list[str]) -> OrderedDict[str, list[int]]:
    result: OrderedDict[str, list[int]] = OrderedDict(
        (name, []) for name in ["student_performance", "instructional_context", "institutional_resources", "student_background"]
    )
    for index, field in enumerate(fields):
        if "marks" in field or "attendance" in field or "grade" in field:
            group = "student_performance"
        elif "teacher" in field or "classroom" in field:
            group = "instructional_context"
        elif any(token in field for token in ["total_students", "total_toilets", "establishment_year", "electricity", "drinking_water"]):
            group = "institutional_resources"
        else:
            group = "student_background"
        result[group].append(index)
    empty = [name for name, indices in result.items() if not indices]
    if empty:
        raise ValueError(f"Alternative grouping has empty domains: {empty}")
    return result


def run_ablation(condition: str, seed: int, root: Path = ROOT) -> Path:
    if condition not in CONDITIONS:
        raise ValueError(condition)
    config = load_config("inels")
    set_global_seed(seed)
    partition = fixed_partition(clean_frame(read_dataset(config, root), config), config)
    encoded = encode_partition(partition, config, "full_record")
    matrix = np.column_stack([encoded.x_num_train, encoded.x_cat_train.astype(np.float32)])
    groups = semantic_groups(encoded.feature_groups)
    model_name = "cfin"
    settings = {**config["architecture"], **config["training"]}
    run_config: dict[str, Any] = {**config, "architecture": dict(config["architecture"]), "training": dict(config["training"])}
    if condition == "without_inter_group_context":
        settings["context_encoder_layers"] = 0
        run_config["architecture"]["context_encoder_layers"] = 0
    elif condition == "flat_transformer":
        model_name = "ft_transformer"
    elif condition == "weighted_cross_entropy":
        run_config["training"]["loss"] = "weighted_cross_entropy"
    elif condition == "unweighted_cross_entropy":
        run_config["training"]["loss"] = "unweighted_cross_entropy"
    elif condition == "random_grouping":
        groups = random_groups(encoded.feature_fields, list(groups), seed)
    elif condition == "data_driven_grouping":
        groups = correlation_groups(matrix)
    elif condition == "alternative_four_domain_grouping":
        groups = alternative_groups(encoded.feature_fields)
    model = build_neural_model(
        model_name,
        encoded.x_num_train.shape[1],
        encoded.category_cardinalities,
        groups,
        len(partition.class_names),
        settings,
    )
    fit = fit_neural(
        model,
        encoded.x_num_train,
        encoded.x_cat_train,
        encoded.y_train,
        config["class_weights"],
        run_config,
        seed,
    )
    device = next(fit.model.parameters()).device
    probability = predict_probabilities(
        fit.model,
        encoded.x_num_test,
        encoded.x_cat_test,
        config["training"]["batch_size"],
        device,
    )
    metrics = classification_metrics(encoded.y_test, probability, partition.class_names, fit.threshold)
    metrics.update({"dataset": "inels", "condition": condition, "seed": seed, "training_seconds": fit.training_seconds})
    output = root / "results" / "ablations" / condition / str(seed)
    output.mkdir(parents=True, exist_ok=True)
    torch.save(fit.model.state_dict(), output / "model.pt")
    write_json(metrics, output / "metrics.json")
    save_yaml(run_config, output / "resolved_config.yaml")
    return output


def aggregate_ablations(root: Path = ROOT) -> pd.DataFrame:
    import json

    rows = []
    for path in (root / "results" / "ablations").glob("*/*/metrics.json"):
        with path.open("r", encoding="utf-8") as handle:
            rows.append(json.load(handle))
    frame = pd.DataFrame(rows)
    summary = frame.groupby("condition")["macro_f1"].agg(["mean", "std"]).reset_index()
    output = root / "results" / "tables"
    output.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output / "ablation_summary.csv", index=False)
    return summary
