from __future__ import annotations

from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd
from scipy.stats import binomtest, norm
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score


def exact_mcnemar(y_true: np.ndarray, prediction_a: np.ndarray, prediction_b: np.ndarray) -> dict[str, float | int]:
    a_correct = prediction_a == y_true
    b_correct = prediction_b == y_true
    a_only = int(np.sum(a_correct & ~b_correct))
    b_only = int(np.sum(~a_correct & b_correct))
    discordant = a_only + b_only
    p_value = 1.0 if discordant == 0 else float(binomtest(min(a_only, b_only), discordant, 0.5).pvalue)
    return {"a_only_correct": a_only, "b_only_correct": b_only, "p_value": p_value}


def _midrank(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values)
    sorted_values = values[order]
    ranks = np.empty(len(values), dtype=float)
    start = 0
    while start < len(values):
        stop = start
        while stop + 1 < len(values) and sorted_values[stop + 1] == sorted_values[start]:
            stop += 1
        ranks[start:stop + 1] = 0.5 * (start + stop) + 1.0
        start = stop + 1
    result = np.empty(len(values), dtype=float)
    result[order] = ranks
    return result


def _fast_delong(predictions: np.ndarray, positives: int) -> tuple[np.ndarray, np.ndarray]:
    negatives = predictions.shape[1] - positives
    positive_predictions = predictions[:, :positives]
    negative_predictions = predictions[:, positives:]
    tx = np.vstack([_midrank(row) for row in positive_predictions])
    ty = np.vstack([_midrank(row) for row in negative_predictions])
    tz = np.vstack([_midrank(row) for row in predictions])
    aucs = tz[:, :positives].sum(axis=1) / positives / negatives - (positives + 1.0) / (2.0 * negatives)
    v01 = (tz[:, :positives] - tx) / negatives
    v10 = 1.0 - (tz[:, positives:] - ty) / positives
    covariance = np.cov(v01) / positives + np.cov(v10) / negatives
    return aucs, np.atleast_2d(covariance)


def paired_delong(y_true: np.ndarray, score_a: np.ndarray, score_b: np.ndarray) -> dict[str, float]:
    order = np.argsort(-y_true)
    positives = int(np.sum(y_true == 1))
    if positives == 0 or positives == len(y_true):
        raise ValueError("DeLong test requires both binary classes")
    aucs, covariance = _fast_delong(np.vstack([score_a, score_b])[:, order], positives)
    contrast = np.array([[1.0, -1.0]])
    variance = float((contrast @ covariance @ contrast.T).item())
    z_score = float(abs(aucs[0] - aucs[1]) / np.sqrt(max(variance, np.finfo(float).eps)))
    p_value = float(2.0 * norm.sf(z_score))
    return {"auc_a": float(aucs[0]), "auc_b": float(aucs[1]), "difference": float(aucs[0] - aucs[1]), "z": z_score, "p_value": p_value}


def paired_stratified_bootstrap(
    y_true: np.ndarray,
    value_a: np.ndarray,
    value_b: np.ndarray,
    metric: Callable[[np.ndarray, np.ndarray], float],
    replicates: int,
    seed: int,
) -> dict[str, float]:
    rng = np.random.default_rng(seed)
    class_indices = [np.flatnonzero(y_true == label) for label in np.unique(y_true)]
    differences = np.empty(replicates, dtype=float)
    for iteration in range(replicates):
        selected = np.concatenate(
            [rng.choice(indices, size=len(indices), replace=True) for indices in class_indices]
        )
        differences[iteration] = metric(y_true[selected], value_a[selected]) - metric(y_true[selected], value_b[selected])
    observed = metric(y_true, value_a) - metric(y_true, value_b)
    if observed >= 0.0:
        p_value = (np.sum(differences <= 0.0) + 1.0) / (replicates + 1.0)
    else:
        p_value = (np.sum(differences >= 0.0) + 1.0) / (replicates + 1.0)
    return {
        "difference": float(observed),
        "ci_low": float(np.quantile(differences, 0.025)),
        "ci_high": float(np.quantile(differences, 0.975)),
        "p_value": float(p_value),
        "replicates": int(replicates),
        "seed": int(seed),
    }


def holm_adjust(p_values: list[float]) -> list[float]:
    count = len(p_values)
    order = np.argsort(p_values)
    adjusted = np.empty(count, dtype=float)
    running = 0.0
    for rank, index in enumerate(order):
        value = min(1.0, (count - rank) * p_values[index])
        running = max(running, value)
        adjusted[index] = running
    return adjusted.tolist()


def _average_predictions(run_root: Path, dataset: str, model: str) -> pd.DataFrame:
    paths = sorted((run_root / dataset / model).glob("*/predictions.csv"), key=lambda path: int(path.parent.name))
    if not paths:
        raise FileNotFoundError(f"No predictions for {dataset}/{model}")
    frames = []
    for path in paths:
        frame = pd.read_csv(path).sort_values("row_index")
        frame["seed"] = int(path.parent.name)
        frames.append(frame)
    combined = pd.concat(frames, ignore_index=True)
    probability_fields = [field for field in combined if field.startswith("probability_")]
    averaged = combined.groupby("row_index", as_index=False)[probability_fields].mean()
    truth = combined.groupby("row_index", as_index=False)["y_true"].first()
    vote_counts = combined.groupby(["row_index", "y_pred"]).size().rename("votes").reset_index()
    winners = vote_counts.sort_values(["row_index", "votes", "y_pred"], ascending=[True, False, True]).drop_duplicates("row_index")
    winners = winners[["row_index", "y_pred"]]
    return truth.merge(averaged, on="row_index").merge(winners, on="row_index").sort_values("row_index")


def compare_cfin_with_ft(run_root: Path, output: Path, replicates: int = 10000, seed: int = 2025) -> pd.DataFrame:
    rows: list[dict[str, float | str]] = []
    for dataset in ("inels", "uci"):
        cfin = _average_predictions(run_root, dataset, "cfin")
        ft = _average_predictions(run_root, dataset, "ft_transformer")
        if not np.array_equal(cfin["row_index"], ft["row_index"]):
            raise ValueError(f"Prediction rows do not align for {dataset}")
        y = cfin["y_true"].to_numpy(dtype=int)
        probability_fields = [field for field in cfin if field.startswith("probability_")]
        cfin_prob = cfin[probability_fields].to_numpy()
        ft_prob = ft[probability_fields].to_numpy()
        cfin_pred = cfin["y_pred"].to_numpy(dtype=int)
        ft_pred = ft["y_pred"].to_numpy(dtype=int)
        mcnemar = exact_mcnemar(y, cfin_pred, ft_pred)
        accuracy_bootstrap = paired_stratified_bootstrap(
            y, cfin_pred, ft_pred, accuracy_score, replicates, seed
        )
        rows.append({"dataset": dataset, "metric": "accuracy", "test": "exact_mcnemar", "difference": accuracy_bootstrap["difference"], "ci_low": accuracy_bootstrap["ci_low"], "ci_high": accuracy_bootstrap["ci_high"], "raw_p": mcnemar["p_value"]})
        f1_test = paired_stratified_bootstrap(
            y,
            cfin_pred,
            ft_pred,
            lambda truth, pred: f1_score(truth, pred, average="macro"),
            replicates,
            seed + 1,
        )
        rows.append({"dataset": dataset, "metric": "macro_f1", "test": "paired_stratified_bootstrap", "difference": f1_test["difference"], "ci_low": f1_test["ci_low"], "ci_high": f1_test["ci_high"], "raw_p": f1_test["p_value"]})
        if dataset == "inels":
            auc_test = paired_delong(y, cfin_prob[:, 1], ft_prob[:, 1])
            auc_ci = paired_stratified_bootstrap(y, cfin_prob[:, 1], ft_prob[:, 1], roc_auc_score, replicates, seed + 2)
            rows.append({"dataset": dataset, "metric": "macro_ovr_auc", "test": "paired_delong", "difference": auc_test["difference"], "ci_low": auc_ci["ci_low"], "ci_high": auc_ci["ci_high"], "raw_p": auc_test["p_value"]})
        else:
            auc_test = paired_stratified_bootstrap(
                y,
                cfin_prob,
                ft_prob,
                lambda truth, probability: roc_auc_score(truth, probability, multi_class="ovr", average="macro"),
                replicates,
                seed + 2,
            )
            rows.append({"dataset": dataset, "metric": "macro_ovr_auc", "test": "paired_stratified_bootstrap", "difference": auc_test["difference"], "ci_low": auc_test["ci_low"], "ci_high": auc_test["ci_high"], "raw_p": auc_test["p_value"]})
    result = pd.DataFrame(rows)
    result["holm_p"] = np.nan
    for dataset, indices in result.groupby("dataset").groups.items():
        result.loc[indices, "holm_p"] = holm_adjust(result.loc[indices, "raw_p"].tolist())
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, index=False)
    return result
