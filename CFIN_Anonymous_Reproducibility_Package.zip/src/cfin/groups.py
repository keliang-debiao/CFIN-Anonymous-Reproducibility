from __future__ import annotations

import re
from collections import OrderedDict
from typing import Any


def field_group(field: str, config: dict[str, Any]) -> str:
    groups = config["groups"]
    for group_name, definition in groups.items():
        if field in definition.get("fields", []):
            return group_name
        if any(re.search(pattern, field) for pattern in definition.get("patterns", [])):
            return group_name
    return config["fallback_group"]


def assign_groups(fields: list[str], config: dict[str, Any]) -> OrderedDict[str, list[int]]:
    assigned: OrderedDict[str, list[int]] = OrderedDict((key, []) for key in config["groups"])
    for index, field in enumerate(fields):
        assigned[field_group(field, config)].append(index)
    empty = [name for name, indices in assigned.items() if not indices]
    if empty:
        raise ValueError(f"No fields assigned to configured groups: {empty}")
    return assigned


def random_groups(fields: list[str], group_names: list[str], seed: int) -> OrderedDict[str, list[int]]:
    import numpy as np

    rng = np.random.default_rng(seed)
    order = rng.permutation(len(fields))
    chunks = np.array_split(order, len(group_names))
    return OrderedDict((name, sorted(chunk.tolist())) for name, chunk in zip(group_names, chunks))
