from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .groups import field_group


def normalize_name(value: str) -> str:
    value = value.strip().lower().replace("'", "")
    value = re.sub(r"[^a-z0-9]+", "_", value)
    return value.strip("_")


def normalize_frame(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    result.columns = [normalize_name(str(column)) for column in result.columns]
    return result


def _normalize_label(value: Any) -> str:
    return normalize_name(str(value))


@dataclass
class DataPartition:
    train: pd.DataFrame
    test: pd.DataFrame
    y_train: np.ndarray
    y_test: np.ndarray
    class_names: list[str]
    train_indices: np.ndarray
    test_indices: np.ndarray


@dataclass
class EncodedPartition:
    x_num_train: np.ndarray
    x_cat_train: np.ndarray
    x_num_test: np.ndarray
    x_cat_test: np.ndarray
    y_train: np.ndarray
    y_test: np.ndarray
    numeric_fields: list[str]
    categorical_fields: list[str]
    category_cardinalities: list[int]
    feature_fields: list[str]
    feature_groups: list[str]


def read_dataset(config: dict[str, Any], root: str | Path) -> pd.DataFrame:
    path = Path(root) / config["dataset"]["file"]
    if not path.exists():
        raise FileNotFoundError(f"Dataset is not registered: {path}")
    return normalize_frame(pd.read_csv(path))


def clean_frame(frame: pd.DataFrame, config: dict[str, Any]) -> pd.DataFrame:
    result = frame.copy()
    cleaning_report: dict[str, Any] = {"corrected_invalid": {}, "clipped": {}}
    key = config["dataset"]["key"]
    if key == "inels":
        for field in config["dataset"].get("missing_value_rules", {}):
            if field in result:
                result[field] = pd.to_numeric(result[field], errors="coerce")
        if "establishment_year" in result:
            limit = config["dataset"]["missing_value_rules"]["establishment_year"]["invalid_above"]
            numeric_year = pd.to_numeric(result["establishment_year"], errors="coerce")
            cleaning_report["corrected_invalid"]["establishment_year"] = int((numeric_year > limit).sum())
            result["establishment_year"] = numeric_year.mask(numeric_year > limit)
        for field, rule in config["dataset"].get("score_rules", {}).items():
            if field in result:
                numeric_score = pd.to_numeric(result[field], errors="coerce")
                outside = (numeric_score < rule["clip_minimum"]) | (numeric_score > rule["clip_maximum"])
                cleaning_report["clipped"][field] = int(outside.sum())
                result[field] = numeric_score.clip(
                    rule["clip_minimum"], rule["clip_maximum"]
                )
    result.attrs["cleaning_report"] = cleaning_report
    return result


def validate_dataset(frame: pd.DataFrame, config: dict[str, Any], strict: bool = True) -> dict[str, Any]:
    data_config = config["dataset"]
    target = normalize_name(data_config["target"])
    issues: list[str] = []
    if len(frame) != data_config["expected_records"]:
        issues.append(f"record count {len(frame)} != {data_config['expected_records']}")
    if target not in frame:
        issues.append(f"target field missing: {target}")
        counts: dict[str, int] = {}
    else:
        counts = frame[target].map(_normalize_label).value_counts().sort_index().to_dict()
        expected = {normalize_name(k): int(v) for k, v in data_config["expected_target_counts"].items()}
        if counts != expected:
            issues.append(f"target counts {counts} != {expected}")
    if "expected_predictors" in data_config:
        predictors = len(frame.columns) - int(target in frame.columns)
        if predictors != data_config["expected_predictors"]:
            issues.append(f"predictor count {predictors} != {data_config['expected_predictors']}")
    if "expected_fields_minimum" in data_config and len(frame.columns) < data_config["expected_fields_minimum"]:
        issues.append(f"field count {len(frame.columns)} < {data_config['expected_fields_minimum']}")
    if data_config["key"] == "inels":
        cleaning_report = frame.attrs.get("cleaning_report", {})
        for field, rule in data_config.get("missing_value_rules", {}).items():
            if field not in frame:
                issues.append(f"required field missing: {field}")
                continue
            expected_missing = rule.get("expected_missing", rule.get("expected_missing_after_correction"))
            if expected_missing is not None and int(frame[field].isna().sum()) != int(expected_missing):
                issues.append(f"{field} missing count {int(frame[field].isna().sum())} != {expected_missing}")
            if "expected_corrected" in rule:
                corrected = cleaning_report.get("corrected_invalid", {}).get(field)
                if corrected != int(rule["expected_corrected"]):
                    issues.append(f"{field} corrected count {corrected} != {rule['expected_corrected']}")
        for field, rule in data_config.get("score_rules", {}).items():
            if field not in frame:
                issues.append(f"required field missing: {field}")
                continue
            clipped = cleaning_report.get("clipped", {}).get(field)
            if clipped != int(rule["expected_clipped"]):
                issues.append(f"{field} clipped count {clipped} != {rule['expected_clipped']}")
            duplicate = rule.get("duplicate_of")
            if duplicate and duplicate in frame:
                equal = np.allclose(
                    pd.to_numeric(frame[field], errors="coerce"),
                    pd.to_numeric(frame[duplicate], errors="coerce"),
                    equal_nan=True,
                )
                if not equal:
                    issues.append(f"{field} is not identical to {duplicate}")
    if strict and issues:
        raise ValueError("; ".join(issues))
    return {"records": len(frame), "fields": len(frame.columns), "target_counts": counts, "issues": issues}


def select_horizon(frame: pd.DataFrame, config: dict[str, Any], horizon: str) -> pd.DataFrame:
    if horizon not in config["horizons"]:
        raise ValueError(f"Unknown horizon: {horizon}")
    target = normalize_name(config["dataset"]["target"])
    excluded = set(config["dataset"].get("excluded_fields", [])) | {target}
    patterns = config["horizons"][horizon].get("exclude_patterns", [])
    fields = [
        field for field in frame.columns
        if field not in excluded and not any(re.search(pattern, field) for pattern in patterns)
    ]
    if not fields:
        raise ValueError(f"No predictors remain for horizon {horizon}")
    return frame[fields].copy()


def fixed_partition(frame: pd.DataFrame, config: dict[str, Any]) -> DataPartition:
    target = normalize_name(config["dataset"]["target"])
    class_names = [normalize_name(value) for value in config["dataset"]["class_order"]]
    label_to_index = {label: index for index, label in enumerate(class_names)}
    labels = frame[target].map(_normalize_label)
    unknown = sorted(set(labels) - set(label_to_index))
    if unknown:
        raise ValueError(f"Unexpected target labels: {unknown}")
    y = labels.map(label_to_index).to_numpy(dtype=np.int64)
    indices = np.arange(len(frame))
    train_idx, test_idx = train_test_split(
        indices,
        train_size=config["protocol"]["train_fraction"],
        random_state=config["protocol"]["split_seed"],
        stratify=y,
    )
    return DataPartition(
        train=frame.iloc[train_idx].reset_index(drop=True),
        test=frame.iloc[test_idx].reset_index(drop=True),
        y_train=y[train_idx],
        y_test=y[test_idx],
        class_names=class_names,
        train_indices=train_idx,
        test_indices=test_idx,
    )


def validate_partition_counts(
    partition: DataPartition, config: dict[str, Any], strict: bool = True
) -> dict[str, Any]:
    expected = config["dataset"].get("expected_split_counts", {})
    train_counts = {
        name: int(np.sum(partition.y_train == index))
        for index, name in enumerate(partition.class_names)
    }
    test_counts = {
        name: int(np.sum(partition.y_test == index))
        for index, name in enumerate(partition.class_names)
    }
    expected_train = {normalize_name(key): int(value) for key, value in expected.get("train", {}).items()}
    expected_test = {normalize_name(key): int(value) for key, value in expected.get("test", {}).items()}
    issues = []
    if expected_train and train_counts != expected_train:
        issues.append(f"training class counts {train_counts} != {expected_train}")
    if expected_test and test_counts != expected_test:
        issues.append(f"test class counts {test_counts} != {expected_test}")
    if strict and issues:
        raise ValueError("; ".join(issues))
    return {"train": train_counts, "test": test_counts, "issues": issues}


class NeuralPreprocessor:
    def __init__(self, config: dict[str, Any]):
        self.config = config
        self.numeric_fields: list[str] = []
        self.categorical_fields: list[str] = []
        self.medians: dict[str, float] = {}
        self.means: dict[str, float] = {}
        self.scales: dict[str, float] = {}
        self.categories: dict[str, dict[str, int]] = {}
        self.missing_indicator_fields: list[str] = []

    def fit(self, frame: pd.DataFrame) -> "NeuralPreprocessor":
        declared = set(self.config.get("continuous_fields", []))
        if self.config["dataset"]["key"] == "inels":
            declared |= {
                field for field in frame.columns
                if pd.api.types.is_numeric_dtype(frame[field]) and frame[field].nunique(dropna=True) > 12
            }
        self.numeric_fields = [field for field in frame.columns if field in declared]
        self.categorical_fields = [field for field in frame.columns if field not in self.numeric_fields]
        rules = self.config["dataset"].get("missing_value_rules", {})
        self.missing_indicator_fields = [field for field in rules if field in frame]
        for field in self.numeric_fields:
            values = pd.to_numeric(frame[field], errors="coerce")
            median = float(values.median())
            filled = values.fillna(median)
            scale = float(filled.std(ddof=0))
            self.medians[field] = median
            self.means[field] = float(filled.mean())
            self.scales[field] = scale if scale > 0 else 1.0
        for field in self.categorical_fields:
            values = frame[field].fillna("__missing__").astype(str)
            self.categories[field] = {
                value: index + 1 for index, value in enumerate(sorted(values.unique()))
            }
        return self

    def transform(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, list[str]]:
        numeric_columns: list[np.ndarray] = []
        numeric_names: list[str] = []
        for field in self.numeric_fields:
            values = pd.to_numeric(frame[field], errors="coerce")
            numeric_columns.append(
                ((values.fillna(self.medians[field]).to_numpy(dtype=np.float32) - self.means[field])
                 / self.scales[field])
            )
            numeric_names.append(field)
            if field in self.missing_indicator_fields:
                numeric_columns.append(values.isna().to_numpy(dtype=np.float32))
                numeric_names.append(f"{field}_missing")
        categorical_columns = []
        for field in self.categorical_fields:
            mapping = self.categories[field]
            values = frame[field].fillna("__missing__").astype(str)
            categorical_columns.append(values.map(mapping).fillna(0).to_numpy(dtype=np.int64))
        x_num = np.column_stack(numeric_columns).astype(np.float32) if numeric_columns else np.empty((len(frame), 0), np.float32)
        x_cat = np.column_stack(categorical_columns).astype(np.int64) if categorical_columns else np.empty((len(frame), 0), np.int64)
        return x_num, x_cat, numeric_names

    @property
    def category_cardinalities(self) -> list[int]:
        return [len(self.categories[field]) + 1 for field in self.categorical_fields]


def encode_partition(partition: DataPartition, config: dict[str, Any], horizon: str) -> EncodedPartition:
    train_fields = select_horizon(partition.train, config, horizon)
    test_fields = partition.test[train_fields.columns].copy()
    encoder = NeuralPreprocessor(config).fit(train_fields)
    x_num_train, x_cat_train, numeric_names = encoder.transform(train_fields)
    x_num_test, x_cat_test, _ = encoder.transform(test_fields)
    feature_fields = numeric_names + encoder.categorical_fields
    feature_groups = [
        field_group(field.removesuffix("_missing"), config) for field in feature_fields
    ]
    return EncodedPartition(
        x_num_train=x_num_train,
        x_cat_train=x_cat_train,
        x_num_test=x_num_test,
        x_cat_test=x_cat_test,
        y_train=partition.y_train,
        y_test=partition.y_test,
        numeric_fields=numeric_names,
        categorical_fields=encoder.categorical_fields,
        category_cardinalities=encoder.category_cardinalities,
        feature_fields=feature_fields,
        feature_groups=feature_groups,
    )


def baseline_matrices(partition: DataPartition, config: dict[str, Any], horizon: str):
    train = select_horizon(partition.train, config, horizon)
    test = partition.test[train.columns].copy()
    return baseline_encode_frames(train, test, config)


def baseline_encode_frames(train: pd.DataFrame, test: pd.DataFrame, config: dict[str, Any]):
    declared = set(config.get("continuous_fields", []))
    numeric = [field for field in train if field in declared]
    categorical = [field for field in train if field not in numeric]
    from sklearn.compose import ColumnTransformer
    from sklearn.impute import SimpleImputer
    from sklearn.pipeline import Pipeline

    transformer = ColumnTransformer(
        [
            ("numeric", Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True)), ("scale", StandardScaler())]), numeric),
            ("categorical", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical),
        ]
    )
    x_train = transformer.fit_transform(train)
    x_test = transformer.transform(test)
    return x_train, x_test, transformer
