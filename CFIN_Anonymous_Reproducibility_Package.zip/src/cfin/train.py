from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from time import perf_counter
from typing import Any

import numpy as np
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset

from .metrics import select_binary_threshold
from .model import WeightedFocalLoss


class ArrayDataset(Dataset):
    def __init__(self, x_num: np.ndarray, x_cat: np.ndarray, y: np.ndarray):
        self.x_num = torch.as_tensor(x_num, dtype=torch.float32)
        self.x_cat = torch.as_tensor(x_cat, dtype=torch.long)
        self.y = torch.as_tensor(y, dtype=torch.long)

    def __len__(self) -> int:
        return len(self.y)

    def __getitem__(self, index: int):
        return self.x_num[index], self.x_cat[index], self.y[index]


@dataclass
class FitResult:
    model: torch.nn.Module
    history: list[dict[str, float]]
    threshold: float | None
    training_seconds: float
    best_epoch: int


def _device(name: str) -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(name)


@torch.no_grad()
def predict_probabilities(
    model: torch.nn.Module,
    x_num: np.ndarray,
    x_cat: np.ndarray,
    batch_size: int,
    device: torch.device,
) -> np.ndarray:
    model.eval()
    loader = DataLoader(
        ArrayDataset(x_num, x_cat, np.zeros(len(x_num), dtype=np.int64)),
        batch_size=batch_size,
        shuffle=False,
    )
    outputs: list[np.ndarray] = []
    for numeric, categorical, _ in loader:
        logits = model(numeric.to(device), categorical.to(device))
        outputs.append(torch.softmax(logits, dim=1).cpu().numpy())
    return np.concatenate(outputs, axis=0)


def fit_neural(
    model: torch.nn.Module,
    x_num: np.ndarray,
    x_cat: np.ndarray,
    y: np.ndarray,
    class_weights: list[float],
    config: dict[str, Any],
    seed: int,
) -> FitResult:
    training = config["training"]
    train_idx, valid_idx = train_test_split(
        np.arange(len(y)), test_size=0.10, random_state=seed, stratify=y
    )
    train_loader = DataLoader(
        ArrayDataset(x_num[train_idx], x_cat[train_idx], y[train_idx]),
        batch_size=int(training["batch_size"]),
        shuffle=True,
        generator=torch.Generator().manual_seed(seed),
    )
    valid_loader = DataLoader(
        ArrayDataset(x_num[valid_idx], x_cat[valid_idx], y[valid_idx]),
        batch_size=int(training["batch_size"]),
        shuffle=False,
    )
    device = _device(str(training["device"]))
    model = model.to(device)
    loss_name = str(training.get("loss", "weighted_focal"))
    if loss_name == "weighted_focal":
        criterion = WeightedFocalLoss(class_weights, float(training["focal_gamma"])).to(device)
    elif loss_name == "weighted_cross_entropy":
        criterion = torch.nn.CrossEntropyLoss(
            weight=torch.tensor(class_weights, dtype=torch.float32, device=device)
        )
    elif loss_name == "unweighted_cross_entropy":
        criterion = torch.nn.CrossEntropyLoss()
    else:
        raise ValueError(f"Unknown loss: {loss_name}")
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=float(training["learning_rate"]), weight_decay=float(training["weight_decay"])
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=int(training["maximum_epochs"])
    )
    best_loss = float("inf")
    best_state = deepcopy(model.state_dict())
    best_epoch = 0
    stale_epochs = 0
    history: list[dict[str, float]] = []
    started = perf_counter()
    for epoch in range(1, int(training["maximum_epochs"]) + 1):
        model.train()
        train_loss = 0.0
        train_count = 0
        for numeric, categorical, target in train_loader:
            numeric, categorical, target = numeric.to(device), categorical.to(device), target.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(numeric, categorical)
            loss = criterion(logits, target)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(training["gradient_clip_norm"]))
            optimizer.step()
            train_loss += float(loss.detach()) * len(target)
            train_count += len(target)
        model.eval()
        valid_loss = 0.0
        valid_count = 0
        with torch.no_grad():
            for numeric, categorical, target in valid_loader:
                numeric, categorical, target = numeric.to(device), categorical.to(device), target.to(device)
                loss = criterion(model(numeric, categorical), target)
                valid_loss += float(loss) * len(target)
                valid_count += len(target)
        scheduler.step()
        mean_train = train_loss / train_count
        mean_valid = valid_loss / valid_count
        history.append({"epoch": float(epoch), "train_loss": mean_train, "valid_loss": mean_valid})
        if mean_valid < best_loss - float(training["minimum_delta"]):
            best_loss = mean_valid
            best_state = deepcopy(model.state_dict())
            best_epoch = epoch
            stale_epochs = 0
        else:
            stale_epochs += 1
        if stale_epochs >= int(training["early_stopping_patience"]):
            break
    training_seconds = perf_counter() - started
    model.load_state_dict(best_state)
    threshold = None
    if len(class_weights) == 2:
        probabilities = predict_probabilities(
            model, x_num[valid_idx], x_cat[valid_idx], int(training["batch_size"]), device
        )
        threshold_config = config["threshold"]
        grid = np.arange(
            float(threshold_config["binary_start"]),
            float(threshold_config["binary_stop"]) + 1e-12,
            float(threshold_config["binary_step"]),
        )
        threshold, _ = select_binary_threshold(y[valid_idx], probabilities[:, 1], grid)
    return FitResult(model, history, threshold, training_seconds, best_epoch)
