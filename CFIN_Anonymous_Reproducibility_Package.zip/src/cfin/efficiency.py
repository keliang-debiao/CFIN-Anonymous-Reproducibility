from __future__ import annotations

import statistics
from time import perf_counter_ns

import numpy as np
import torch


@torch.no_grad()
def benchmark_model(
    model: torch.nn.Module,
    x_num: np.ndarray,
    x_cat: np.ndarray,
    batch_size: int,
    warmup_passes: int,
    timed_passes: int,
) -> dict[str, float | int]:
    device = next(model.parameters()).device
    numeric = torch.as_tensor(x_num[:batch_size], dtype=torch.float32, device=device)
    categorical = torch.as_tensor(x_cat[:batch_size], dtype=torch.long, device=device)
    if len(numeric) < batch_size:
        repeats = int(np.ceil(batch_size / len(numeric)))
        numeric = numeric.repeat((repeats, 1))[:batch_size]
        categorical = categorical.repeat((repeats, 1))[:batch_size]
    model.eval()
    for _ in range(warmup_passes):
        model(numeric, categorical)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elapsed = []
    for _ in range(timed_passes):
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        started = perf_counter_ns()
        model(numeric, categorical)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        elapsed.append((perf_counter_ns() - started) / 1_000_000.0)
    parameters = sum(parameter.numel() for parameter in model.parameters())
    return {
        "batch_size": batch_size,
        "warmup_passes": warmup_passes,
        "timed_passes": timed_passes,
        "latency_milliseconds_median": float(statistics.median(elapsed)),
        "latency_milliseconds_iqr": float(np.quantile(elapsed, 0.75) - np.quantile(elapsed, 0.25)),
        "parameters": int(parameters),
        "device": str(device),
    }
