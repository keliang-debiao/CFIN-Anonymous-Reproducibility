from __future__ import annotations

from collections import OrderedDict
from typing import Any

import torch
from torch import nn
from torch.nn import functional as F


class FeatureTokenizer(nn.Module):
    def __init__(self, n_numeric: int, category_cardinalities: list[int], dimension: int):
        super().__init__()
        self.n_numeric = n_numeric
        self.n_categorical = len(category_cardinalities)
        self.dimension = dimension
        if n_numeric:
            self.numeric_weight = nn.Parameter(torch.empty(n_numeric, dimension))
            self.numeric_bias = nn.Parameter(torch.empty(n_numeric, dimension))
            nn.init.xavier_uniform_(self.numeric_weight)
            nn.init.zeros_(self.numeric_bias)
        self.category_embeddings = nn.ModuleList(
            nn.Embedding(cardinality, dimension) for cardinality in category_cardinalities
        )
        self.feature_identity = nn.Parameter(
            torch.empty(n_numeric + len(category_cardinalities), dimension)
        )
        nn.init.normal_(self.feature_identity, std=0.02)

    def forward(self, x_num: torch.Tensor, x_cat: torch.Tensor) -> torch.Tensor:
        parts: list[torch.Tensor] = []
        if self.n_numeric:
            parts.append(x_num.unsqueeze(-1) * self.numeric_weight + self.numeric_bias)
        if self.n_categorical:
            parts.append(
                torch.stack(
                    [embedding(x_cat[:, index]) for index, embedding in enumerate(self.category_embeddings)],
                    dim=1,
                )
            )
        tokens = torch.cat(parts, dim=1)
        return tokens + self.feature_identity.unsqueeze(0)


def _encoder_layer(dimension: int, heads: int, feedforward: int, dropout: float) -> nn.TransformerEncoderLayer:
    return nn.TransformerEncoderLayer(
        d_model=dimension,
        nhead=heads,
        dim_feedforward=feedforward,
        dropout=dropout,
        activation="gelu",
        batch_first=True,
        norm_first=True,
    )


class CFIN(nn.Module):
    def __init__(
        self,
        n_numeric: int,
        category_cardinalities: list[int],
        groups: OrderedDict[str, list[int]],
        n_classes: int,
        settings: dict[str, Any],
    ):
        super().__init__()
        dimension = int(settings["token_dimension"])
        dropout = float(settings["dropout"])
        self.tokenizer = FeatureTokenizer(n_numeric, category_cardinalities, dimension)
        self.groups = groups
        self.group_tokens = nn.ParameterDict(
            {name: nn.Parameter(torch.empty(1, 1, dimension)) for name in groups}
        )
        for value in self.group_tokens.values():
            nn.init.normal_(value, std=0.02)
        self.group_encoders = nn.ModuleDict(
            {
                name: nn.TransformerEncoder(
                    _encoder_layer(
                        dimension,
                        int(settings["group_attention_heads"]),
                        int(settings["group_feedforward_dimension"]),
                        dropout,
                    ),
                    num_layers=int(settings["group_encoder_layers"]),
                    enable_nested_tensor=False,
                )
                for name in groups
            }
        )
        self.context_token = nn.Parameter(torch.empty(1, 1, dimension))
        nn.init.normal_(self.context_token, std=0.02)
        context_layers = int(settings["context_encoder_layers"])
        self.context_encoder = (
            nn.TransformerEncoder(
                _encoder_layer(
                    dimension,
                    int(settings["context_attention_heads"]),
                    int(settings["context_feedforward_dimension"]),
                    dropout,
                ),
                num_layers=context_layers,
                enable_nested_tensor=False,
            )
            if context_layers > 0
            else None
        )
        self.head = nn.Sequential(
            nn.LayerNorm(dimension),
            nn.Linear(dimension, int(settings["head_hidden_dimension"])),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(int(settings["head_hidden_dimension"]), n_classes),
        )

    def forward(self, x_num: torch.Tensor, x_cat: torch.Tensor) -> torch.Tensor:
        tokens = self.tokenizer(x_num, x_cat)
        summaries: list[torch.Tensor] = []
        for name, indices in self.groups.items():
            group_fields = tokens[:, indices, :]
            group_token = self.group_tokens[name].expand(tokens.shape[0], -1, -1)
            encoded = self.group_encoders[name](torch.cat([group_token, group_fields], dim=1))
            summaries.append(encoded[:, 0, :])
        group_sequence = torch.stack(summaries, dim=1)
        if self.context_encoder is None:
            return self.head(group_sequence.mean(dim=1))
        context_token = self.context_token.expand(tokens.shape[0], -1, -1)
        context = self.context_encoder(torch.cat([context_token, group_sequence], dim=1))
        return self.head(context[:, 0, :])


class FTTransformer(nn.Module):
    def __init__(
        self,
        n_numeric: int,
        category_cardinalities: list[int],
        n_classes: int,
        settings: dict[str, Any],
    ):
        super().__init__()
        dimension = int(settings["token_dimension"])
        dropout = float(settings["dropout"])
        self.tokenizer = FeatureTokenizer(n_numeric, category_cardinalities, dimension)
        self.class_token = nn.Parameter(torch.empty(1, 1, dimension))
        nn.init.normal_(self.class_token, std=0.02)
        self.encoder = nn.TransformerEncoder(
            _encoder_layer(
                dimension,
                int(settings["context_attention_heads"]),
                int(settings["context_feedforward_dimension"]),
                dropout,
            ),
            num_layers=int(settings["context_encoder_layers"]),
            enable_nested_tensor=False,
        )
        self.head = nn.Sequential(nn.LayerNorm(dimension), nn.Linear(dimension, n_classes))

    def forward(self, x_num: torch.Tensor, x_cat: torch.Tensor) -> torch.Tensor:
        tokens = self.tokenizer(x_num, x_cat)
        class_token = self.class_token.expand(tokens.shape[0], -1, -1)
        encoded = self.encoder(torch.cat([class_token, tokens], dim=1))
        return self.head(encoded[:, 0, :])


class WeightedFocalLoss(nn.Module):
    def __init__(self, class_weights: list[float], gamma: float = 2.0):
        super().__init__()
        self.register_buffer("class_weights", torch.tensor(class_weights, dtype=torch.float32))
        self.gamma = gamma

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        log_probabilities = F.log_softmax(logits, dim=1)
        probabilities = log_probabilities.exp()
        row = torch.arange(target.shape[0], device=target.device)
        log_pt = log_probabilities[row, target]
        pt = probabilities[row, target]
        weights = self.class_weights[target]
        return (-weights * (1.0 - pt).pow(self.gamma) * log_pt).mean()


def build_neural_model(
    model_name: str,
    n_numeric: int,
    category_cardinalities: list[int],
    groups: OrderedDict[str, list[int]],
    n_classes: int,
    settings: dict[str, Any],
) -> nn.Module:
    if model_name == "cfin":
        return CFIN(n_numeric, category_cardinalities, groups, n_classes, settings)
    if model_name == "ft_transformer":
        return FTTransformer(n_numeric, category_cardinalities, n_classes, settings)
    raise ValueError(f"Unsupported neural model: {model_name}")
