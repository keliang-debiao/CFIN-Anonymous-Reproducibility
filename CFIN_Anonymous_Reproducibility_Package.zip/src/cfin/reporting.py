from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


METRICS = ["accuracy", "macro_precision", "macro_recall", "macro_f1", "macro_ovr_auc"]


def aggregate_runs(run_root: Path, output: Path) -> pd.DataFrame:
    rows = []
    for path in run_root.glob("*/*/*/metrics.json"):
        with path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        rows.append({key: value.get(key) for key in ["dataset", "model", "seed", "horizon", "training_seconds", *METRICS]})
    if not rows:
        raise FileNotFoundError(f"No run metrics under {run_root}")
    result = pd.DataFrame(rows).sort_values(["dataset", "model", "seed"])
    output.mkdir(parents=True, exist_ok=True)
    result.to_csv(output / "seed_metrics.csv", index=False)
    summary = result.groupby(["dataset", "model", "horizon"])[METRICS + ["training_seconds"]].agg(["mean", "std"])
    summary.columns = ["_".join(column) for column in summary.columns]
    summary.reset_index().to_csv(output / "performance_summary.csv", index=False)
    return result


def aggregate_horizons(results_root: Path, output: Path) -> pd.DataFrame:
    rows = []
    for dataset in ("inels", "uci"):
        for path in (results_root / "runs" / dataset / "cfin").glob("*/metrics.json"):
            with path.open("r", encoding="utf-8") as handle:
                rows.append(json.load(handle))
    for path in (results_root / "horizon_runs").glob("*/*/cfin/*/metrics.json"):
        with path.open("r", encoding="utf-8") as handle:
            rows.append(json.load(handle))
    if not rows:
        raise FileNotFoundError("No horizon metrics found")
    frame = pd.DataFrame(rows).drop_duplicates(subset=["dataset", "horizon", "seed"], keep="last")
    sensitivity = frame[frame["horizon"] == "science_retained"]
    if not sensitivity.empty:
        sensitivity_summary = sensitivity.groupby(["dataset", "horizon"])[["macro_f1", "macro_ovr_auc"]].agg(["mean", "std"])
        sensitivity_summary.columns = ["_".join(column) for column in sensitivity_summary.columns]
        sensitivity_summary.reset_index().to_csv(output / "sensitivity_summary.csv", index=False)
    horizon_frame = frame[frame["horizon"] != "science_retained"]
    summary = horizon_frame.groupby(["dataset", "horizon"])[["macro_f1", "macro_ovr_auc"]].agg(["mean", "std"])
    summary.columns = ["_".join(column) for column in summary.columns]
    summary = summary.reset_index()
    summary.to_csv(output / "horizon_summary.csv", index=False)
    return summary


def aggregate_attribution(results_root: Path, output: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    feature_paths = sorted((results_root / "attribution").glob("*_feature_attribution.csv"))
    group_paths = sorted((results_root / "attribution").glob("*_group_attribution.csv"))
    if not feature_paths or not group_paths:
        raise FileNotFoundError("Attribution outputs are incomplete")
    feature = pd.concat([pd.read_csv(path) for path in feature_paths], ignore_index=True)
    group = pd.concat([pd.read_csv(path) for path in group_paths], ignore_index=True)
    feature_summary = feature.groupby(["dataset", "feature", "group"])["mean_absolute_shap"].agg(["mean", "std"]).reset_index()
    group_summary = group.groupby(["dataset", "group"])[["mean_absolute_shap", "percent"]].agg(["mean", "std"])
    group_summary.columns = ["_".join(column) for column in group_summary.columns]
    group_summary = group_summary.reset_index()
    feature_summary.to_csv(output / "feature_attribution_summary.csv", index=False)
    group_summary.to_csv(output / "group_attribution_summary.csv", index=False)
    return feature_summary, group_summary


def generate_all_tables(results_root: Path, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    aggregate_runs(results_root / "runs", output)
    aggregate_horizons(results_root, output)
    if (results_root / "attribution").exists():
        aggregate_attribution(results_root, output)


def compare_targets(generated: Path, targets: Path, output: Path) -> pd.DataFrame:
    generated_frame = pd.read_csv(generated)
    target_frame = pd.read_csv(targets)
    keys = [field for field in ("dataset", "model", "horizon", "metric") if field in generated_frame and field in target_frame]
    merged = generated_frame.merge(target_frame, on=keys, suffixes=("_generated", "_target"))
    numeric_pairs = []
    for field in target_frame.select_dtypes(include="number").columns:
        if f"{field}_generated" in merged and f"{field}_target" in merged:
            merged[f"{field}_difference"] = merged[f"{field}_generated"] - merged[f"{field}_target"]
            numeric_pairs.append(field)
    output.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(output, index=False)
    return merged
