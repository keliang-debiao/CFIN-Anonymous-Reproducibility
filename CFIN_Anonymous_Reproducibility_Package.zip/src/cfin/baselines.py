from __future__ import annotations

from typing import Any

from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression


def build_baseline(name: str, seed: int, n_classes: int, settings: dict[str, Any] | None = None):
    settings = dict(settings or {})
    if name == "logistic_regression":
        return LogisticRegression(
            C=float(settings.get("C", 1.0)),
            penalty=settings.get("penalty", "l2"),
            solver=settings.get("solver", "liblinear" if n_classes == 2 else "saga"),
            class_weight="balanced",
            max_iter=5000,
            random_state=seed,
        )
    if name == "random_forest":
        return RandomForestClassifier(
            n_estimators=int(settings.get("n_estimators", 500)),
            max_depth=settings.get("max_depth"),
            min_samples_split=int(settings.get("min_samples_split", 2)),
            max_features=settings.get("max_features", "sqrt"),
            class_weight="balanced",
            n_jobs=-1,
            random_state=seed,
        )
    if name == "xgboost":
        from xgboost import XGBClassifier

        objective = "binary:logistic" if n_classes == 2 else "multi:softprob"
        return XGBClassifier(
            n_estimators=int(settings.get("n_estimators", 500)),
            max_depth=int(settings.get("max_depth", 6)),
            learning_rate=float(settings.get("learning_rate", 0.05)),
            subsample=float(settings.get("subsample", 0.9)),
            colsample_bytree=float(settings.get("colsample_bytree", 0.9)),
            objective=objective,
            eval_metric="logloss",
            n_jobs=-1,
            random_state=seed,
        )
    raise ValueError(f"Unsupported conventional baseline: {name}")
