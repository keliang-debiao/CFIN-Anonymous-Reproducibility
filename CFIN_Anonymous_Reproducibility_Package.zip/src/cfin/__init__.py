"""CFIN anonymous reproducibility workflow."""

__version__ = "1.0.0"
