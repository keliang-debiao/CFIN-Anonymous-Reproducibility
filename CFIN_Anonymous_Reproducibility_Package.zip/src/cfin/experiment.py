from __future__ import annotations

import json
from collections import OrderedDict
from pathlib import Path
from time import perf_counter
from typing import Any

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from .baselines import build_baseline
from .config import ROOT, load_config, save_yaml
from .data import (
    baseline_encode_frames,
    baseline_matrices,
    clean_frame,
    encode_partition,
    fixed_partition,
    read_dataset,
    select_horizon,
    validate_dataset,
    validate_partition_counts,
)
from .metrics import classification_metrics, select_binary_threshold
from .utils import hardware_record, package_inventory, read_json, set_global_seed, sha256_file, utc_now, write_json


CONVENTIONAL = {"logistic_regression", "random_forest", "xgboost"}
NEURAL = {"ft_transformer", "cfin"}


def default_horizon(dataset: str) -> str:
    return "full_record" if dataset == "inels" else "t2_second_semester"


def _group_indices(group_labels: list[str]) -> OrderedDict[str, list[int]]:
    groups: OrderedDict[str, list[int]] = OrderedDict()
    for index, group in enumerate(group_labels):
        groups.setdefault(group, []).append(index)
    return groups


def _write_predictions(
    path: Path,
    row_indices: np.ndarray,
    y_true: np.ndarray,
    probabilities: np.ndarray,
    class_names: list[str],
    threshold: float | None,
) -> None:
    if probabilities.shape[1] == 2 and threshold is not None:
        prediction = (probabilities[:, 1] >= threshold).astype(int)
    else:
        prediction = probabilities.argmax(axis=1)
    frame = pd.DataFrame({"row_index": row_indices, "y_true": y_true, "y_pred": prediction})
    for index, name in enumerate(class_names):
        frame[f"probability_{name}"] = probabilities[:, index]
    frame.to_csv(path, index=False)


def _selected_settings(root: Path, dataset: str, model_name: str) -> dict[str, Any]:
    path = root / "results" / "tuning" / dataset / model_name / "best.json"
    if not path.exists():
        return {}
    settings = dict(read_json(path).get("best_params", {}))
    if settings.get("max_features") == "all":
        settings["max_features"] = 1.0
    elif settings.get("max_features") == "half":
        settings["max_features"] = 0.5
    return settings


def _append_event(output: Path, event: str, details: dict[str, Any], reset: bool = False) -> None:
    record = {"time_utc": utc_now(), "event": event, **details}
    with (output / "events.jsonl").open("w" if reset else "a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")


def run_experiment(
    dataset: str,
    model_name: str,
    seed: int,
    horizon: str | None = None,
    allow_data_variance: bool = False,
    root: Path = ROOT,
) -> Path:
    config = load_config(dataset)
    selected_settings = _selected_settings(root, dataset, model_name)
    horizon = horizon or default_horizon(dataset)
    set_global_seed(seed, bool(config["training"]["deterministic_algorithms"]))
    raw_path = root / config["dataset"]["file"]
    frame = clean_frame(read_dataset(config, root), config)
    validation = validate_dataset(frame, config, strict=not allow_data_variance)
    partition = fixed_partition(frame, config)
    split_validation = validate_partition_counts(partition, config, strict=not allow_data_variance)
    if horizon == default_horizon(dataset):
        output = root / "results" / "runs" / dataset / model_name / str(seed)
    else:
        output = root / "results" / "horizon_runs" / dataset / horizon / model_name / str(seed)
    output.mkdir(parents=True, exist_ok=True)
    _append_event(output, "run_started", {"dataset": dataset, "model": model_name, "seed": seed, "horizon": horizon}, reset=True)
    resolved = dict(config)
    resolved["architecture"] = {
        **config["architecture"],
        **{key: value for key, value in selected_settings.items() if key in config["architecture"]},
    }
    resolved["training"] = {
        **config["training"],
        **{key: value for key, value in selected_settings.items() if key in config["training"]},
    }
    resolved["run"] = {
        "dataset": dataset,
        "model": model_name,
        "seed": seed,
        "horizon": horizon,
        "started_utc": utc_now(),
        "data_sha256": sha256_file(raw_path),
        "data_validation": validation,
        "split_validation": split_validation,
        "selected_hyperparameters": selected_settings,
    }
    save_yaml(resolved, output / "resolved_config.yaml")
    _append_event(output, "data_validated", {"data_sha256": resolved["run"]["data_sha256"]})
    write_json(hardware_record(), output / "hardware.json")
    (output / "packages.txt").write_text("\n".join(package_inventory()) + "\n", encoding="utf-8")
    threshold: float | None = None
    if model_name in CONVENTIONAL:
        fit_idx, valid_idx = train_test_split(
            np.arange(len(partition.y_train)), test_size=0.10, random_state=seed, stratify=partition.y_train
        )
        raw_train = select_horizon(partition.train, config, horizon)
        x_fit, x_valid, _ = baseline_encode_frames(
            raw_train.iloc[fit_idx], raw_train.iloc[valid_idx], config
        )
        threshold_model = build_baseline(model_name, seed, len(partition.class_names), selected_settings)
        fit_arguments: dict[str, Any] = {}
        if model_name == "xgboost":
            from sklearn.utils.class_weight import compute_sample_weight

            fit_arguments["sample_weight"] = compute_sample_weight("balanced", partition.y_train[fit_idx])
        threshold_model.fit(x_fit, partition.y_train[fit_idx], **fit_arguments)
        if len(partition.class_names) == 2:
            valid_probability = threshold_model.predict_proba(x_valid)[:, 1]
            threshold_config = config["threshold"]
            grid = np.arange(
                threshold_config["binary_start"],
                threshold_config["binary_stop"] + 1e-12,
                threshold_config["binary_step"],
            )
            threshold, _ = select_binary_threshold(partition.y_train[valid_idx], valid_probability, grid)
        x_train, x_test, transformer = baseline_matrices(partition, config, horizon)
        model = build_baseline(model_name, seed, len(partition.class_names), selected_settings)
        final_fit_arguments: dict[str, Any] = {}
        if model_name == "xgboost":
            from sklearn.utils.class_weight import compute_sample_weight

            final_fit_arguments["sample_weight"] = compute_sample_weight("balanced", partition.y_train)
        started = perf_counter()
        model.fit(x_train, partition.y_train, **final_fit_arguments)
        training_seconds = perf_counter() - started
        probabilities = model.predict_proba(x_test)
        import joblib

        joblib.dump({"transformer": transformer, "model": model}, output / "model.joblib")
        history: list[dict[str, float]] = []
        best_epoch = None
    elif model_name == "tabnet":
        from pytorch_tabnet.tab_model import TabNetClassifier
        import torch

        fit_idx, valid_idx = train_test_split(
            np.arange(len(partition.y_train)), test_size=0.10, random_state=seed, stratify=partition.y_train
        )
        raw_train = select_horizon(partition.train, config, horizon)
        x_fit, x_valid, _ = baseline_encode_frames(
            raw_train.iloc[fit_idx], raw_train.iloc[valid_idx], config
        )
        if hasattr(x_fit, "toarray"):
            x_fit = x_fit.toarray()
            x_valid = x_valid.toarray()
        x_fit = np.asarray(x_fit, dtype=np.float32)
        x_valid = np.asarray(x_valid, dtype=np.float32)
        model = TabNetClassifier(
            n_d=int(selected_settings.get("n_d", 32)),
            n_a=int(selected_settings.get("n_a", 32)),
            n_steps=int(selected_settings.get("n_steps", 5)),
            gamma=float(selected_settings.get("gamma", 1.5)),
            lambda_sparse=float(selected_settings.get("lambda_sparse", 0.0001)),
            optimizer_fn=torch.optim.AdamW,
            optimizer_params={"lr": config["training"]["learning_rate"], "weight_decay": config["training"]["weight_decay"]},
            seed=seed,
            verbose=0,
        )
        model.fit(
            x_fit,
            partition.y_train[fit_idx],
            eval_set=[(x_valid, partition.y_train[valid_idx])],
            eval_name=["validation"],
            eval_metric=["logloss"],
            max_epochs=int(config["training"]["maximum_epochs"]),
            patience=int(config["training"]["early_stopping_patience"]),
            batch_size=int(config["training"]["batch_size"]),
            virtual_batch_size=128,
            weights=1,
            num_workers=0,
            drop_last=False,
        )
        selected_epochs = int(getattr(model, "best_epoch", int(config["training"]["maximum_epochs"]) - 1)) + 1
        if len(partition.class_names) == 2:
            valid_probability = model.predict_proba(x_valid)[:, 1]
            threshold_config = config["threshold"]
            grid = np.arange(
                threshold_config["binary_start"],
                threshold_config["binary_stop"] + 1e-12,
                threshold_config["binary_step"],
            )
            threshold, _ = select_binary_threshold(partition.y_train[valid_idx], valid_probability, grid)
        x_train, x_test, transformer = baseline_matrices(partition, config, horizon)
        if hasattr(x_train, "toarray"):
            x_train = x_train.toarray()
            x_test = x_test.toarray()
        x_train = np.asarray(x_train, dtype=np.float32)
        x_test = np.asarray(x_test, dtype=np.float32)
        model = TabNetClassifier(
            n_d=int(selected_settings.get("n_d", 32)),
            n_a=int(selected_settings.get("n_a", 32)),
            n_steps=int(selected_settings.get("n_steps", 5)),
            gamma=float(selected_settings.get("gamma", 1.5)),
            lambda_sparse=float(selected_settings.get("lambda_sparse", 0.0001)),
            optimizer_fn=torch.optim.AdamW,
            optimizer_params={"lr": config["training"]["learning_rate"], "weight_decay": config["training"]["weight_decay"]},
            seed=seed,
            verbose=0,
        )
        started = perf_counter()
        model.fit(
            x_train,
            partition.y_train,
            max_epochs=max(1, selected_epochs),
            patience=0,
            batch_size=int(config["training"]["batch_size"]),
            virtual_batch_size=128,
            weights=1,
            num_workers=0,
            drop_last=False,
        )
        training_seconds = perf_counter() - started
        probabilities = model.predict_proba(x_test)
        model.save_model(str(output / "model"))
        import joblib

        joblib.dump(transformer, output / "transformer.joblib")
        history = []
        best_epoch = selected_epochs
    elif model_name in NEURAL:
        from .model import build_neural_model
        from .train import fit_neural, predict_probabilities

        encoded = encode_partition(partition, config, horizon)
        groups = _group_indices(encoded.feature_groups)
        settings = {**config["architecture"], **config["training"], **selected_settings}
        neural_config = {
            **config,
            "architecture": {**config["architecture"], **selected_settings},
            "training": {**config["training"], **selected_settings},
        }
        model = build_neural_model(
            model_name,
            encoded.x_num_train.shape[1],
            encoded.category_cardinalities,
            groups,
            len(partition.class_names),
            settings,
        )
        fit = fit_neural(
            model,
            encoded.x_num_train,
            encoded.x_cat_train,
            encoded.y_train,
            config["class_weights"],
            neural_config,
            seed,
        )
        import torch

        device = next(fit.model.parameters()).device
        probabilities = predict_probabilities(
            fit.model,
            encoded.x_num_test,
            encoded.x_cat_test,
            int(config["training"]["batch_size"]),
            device,
        )
        torch.save(fit.model.state_dict(), output / "model.pt")
        write_json(
            {
                "numeric_fields": encoded.numeric_fields,
                "categorical_fields": encoded.categorical_fields,
                "category_cardinalities": encoded.category_cardinalities,
                "feature_fields": encoded.feature_fields,
                "feature_groups": encoded.feature_groups,
            },
            output / "feature_registry.json",
        )
        threshold = fit.threshold
        training_seconds = fit.training_seconds
        history = fit.history
        best_epoch = fit.best_epoch
    else:
        raise ValueError(f"Unsupported model: {model_name}")
    metrics = classification_metrics(
        partition.y_test, probabilities, partition.class_names, threshold
    )
    metrics.update(
        {
            "dataset": dataset,
            "model": model_name,
            "seed": seed,
            "horizon": horizon,
            "training_seconds": training_seconds,
            "best_epoch": best_epoch,
        }
    )
    write_json(metrics, output / "metrics.json")
    _append_event(output, "evaluation_completed", {"accuracy": metrics["accuracy"], "macro_f1": metrics["macro_f1"], "macro_ovr_auc": metrics["macro_ovr_auc"], "training_seconds": training_seconds})
    write_json(history, output / "history.json")
    _write_predictions(
        output / "predictions.csv",
        partition.test_indices,
        partition.y_test,
        probabilities,
        partition.class_names,
        threshold,
    )
    write_json({"completed_utc": utc_now(), "status": "complete"}, output / "run_status.json")
    _append_event(output, "run_completed", {"status": "complete"})
    return output
