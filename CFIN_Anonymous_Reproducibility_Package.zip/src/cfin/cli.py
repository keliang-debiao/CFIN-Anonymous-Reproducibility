from __future__ import annotations

import argparse
from pathlib import Path

from .config import ROOT


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cfin", description="CFIN reproducibility workflow")
    subparsers = parser.add_subparsers(dest="command", required=True)
    run = subparsers.add_parser("run", help="fit and evaluate one configured run")
    run.add_argument("--dataset", choices=["inels", "uci"], required=True)
    run.add_argument("--model", choices=["logistic_regression", "random_forest", "xgboost", "tabnet", "ft_transformer", "cfin"], required=True)
    run.add_argument("--seed", type=int, required=True)
    run.add_argument("--horizon")
    run.add_argument("--allow-data-variance", action="store_true")

    tune = subparsers.add_parser("tune", help="run training-only cross-validation")
    tune.add_argument("--dataset", choices=["inels", "uci"], required=True)
    tune.add_argument("--model", choices=["logistic_regression", "random_forest", "xgboost", "tabnet", "ft_transformer", "cfin"], required=True)

    statistics = subparsers.add_parser("statistics", help="run paired statistical comparisons")
    statistics.add_argument("--replicates", type=int, default=10000)
    statistics.add_argument("--seed", type=int, default=2025)

    attribution = subparsers.add_parser("attribution", help="compute permutation SHAP attribution")
    attribution.add_argument("--dataset", choices=["inels", "uci"], required=True)
    attribution.add_argument("--seed", type=int, required=True)

    report = subparsers.add_parser("report", help="aggregate run outputs")
    report.add_argument("--run-root", type=Path, default=ROOT / "results" / "runs")
    report.add_argument("--output", type=Path, default=ROOT / "results" / "tables")

    compare = subparsers.add_parser("compare-targets", help="compare generated and manuscript-reported tables")
    compare.add_argument("--generated", type=Path, required=True)
    compare.add_argument("--targets", type=Path, required=True)
    compare.add_argument("--output", type=Path, default=ROOT / "results" / "target_comparison.csv")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    if args.command == "run":
        from .experiment import run_experiment

        result = run_experiment(args.dataset, args.model, args.seed, args.horizon, args.allow_data_variance)
    elif args.command == "tune":
        from .tuning import tune_model

        result = tune_model(args.dataset, args.model)
    elif args.command == "statistics":
        from .statistics import compare_cfin_with_ft

        result = compare_cfin_with_ft(
            ROOT / "results" / "runs",
            ROOT / "results" / "statistics" / "pairwise_tests.csv",
            args.replicates,
            args.seed,
        )
    elif args.command == "attribution":
        from .interpret import run_attribution

        result = run_attribution(args.dataset, args.seed, ROOT / "results" / "attribution")
    elif args.command == "report":
        from .reporting import generate_all_tables

        result = generate_all_tables(ROOT / "results", args.output)
    elif args.command == "compare-targets":
        from .reporting import compare_targets

        result = compare_targets(args.generated, args.targets, args.output)
    else:
        raise RuntimeError(args.command)
    print(result)


if __name__ == "__main__":
    main()
