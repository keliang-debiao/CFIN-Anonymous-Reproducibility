# Log Provenance

`pipeline_verification.log` is an executed record of the fast repository validation workflow. It is intentionally limited to data-flow, preprocessing, metric, threshold, and statistical-test checks performed on a deterministic in-memory fixture. It is not evidence for the manuscript's empirical claims.

`test_run.log` records the executed unit and protocol test suite. Neural forward-pass tests are skipped when PyTorch is unavailable in the host used to build the archive; the locked environment installs PyTorch and runs that test.

Full experiments create separate run logs and machine-readable records under `results/`. Their required provenance fields are defined in `REPRODUCIBILITY.md`.
