# AI Experiment Runbook

This runbook defines the execution contract for an automated coding or research agent operating this repository.

## Non-negotiable rules

1. Read `README.md`, `DATA.md`, `REPRODUCIBILITY.md`, and all YAML files under `configs/` before running an experiment.
2. Never use files under `manuscript_targets/` as training input, test input, parameter input, threshold input, or generated output.
3. Treat `manuscript_targets/` only as a post-run comparison reference.
4. Do not change the fixed split seed, evaluation seeds, class order, prediction horizons, metric definitions, or correction rules unless the change is recorded as a separate sensitivity run.
5. Fit imputers, scalers, category vocabularies, and thresholds without access to the test partition.
6. Preserve row indices in every prediction file so paired tests can verify alignment.
7. Do not report a run as complete unless its status file, predictions, metrics, resolved configuration, data digest, package inventory, hardware record, and model state are present.
8. Never replace an unsuccessful run with manuscript-reported values. Retain the failure log and diagnose the cause.

## Execution order

### Gate 1: repository validation

```bash
python scripts/verify_pipeline.py
python scripts/run_tests_with_log.py
python scripts/check_repository.py
```

Proceed only when all three commands return a passing status.

### Gate 2: source-data registration

```bash
python scripts/fetch_data.py --dataset uci
python scripts/fetch_data.py --dataset inels
```

Confirm that each registration sidecar contains the expected record count, target counts, and a SHA-256 digest. Stop if strict validation fails. Use `--allow-data-variance` only for a deliberately separate analysis, and retain the variance record.

### Gate 3: training-only model selection

```bash
python scripts/run_study.py --stage tune
```

Confirm that each dataset/model directory under `results/tuning/` contains `study.sqlite`, `trials.csv`, and `best.json`, and that every study contains 50 completed trials.

### Gate 4: final seeded runs

```bash
python scripts/run_study.py --stage train
```

Confirm ten complete seed directories for each dataset/model pair. Confirm that test row indices are identical across models within a dataset.

### Gate 5: supplementary analyses

```bash
python scripts/run_study.py --stage horizons
python scripts/run_study.py --stage sensitivity
python scripts/run_study.py --stage ablation
python scripts/run_study.py --stage statistics
python scripts/run_study.py --stage attribution
python scripts/run_study.py --stage efficiency
```

### Gate 6: reporting

```bash
python scripts/run_study.py --stage report
```

Inspect generated tables under `results/tables/`. Compare them with the separate reference files only after all required runs have passed their integrity checks.

## Discrepancy protocol

When a generated value differs from the manuscript target:

1. Retain the generated value and all provenance files.
2. Check the data digest and registration report.
3. Check package and CUDA versions.
4. Confirm class order and positive-class selection.
5. Confirm selected hyperparameters and the threshold stored for that seed.
6. Confirm that the statistical input uses aligned row indices and matched seeds.
7. Quantify the discrepancy in `results/target_comparison.csv`.
8. Change code only when a documented protocol mismatch or implementation defect is identified; rerun all downstream stages affected by that change.

## Completion criteria

A reproduction is complete only when the main performance table, horizon table, sensitivity result, ablation table, pairwise statistical table, feature attribution table, group attribution table, and efficiency table are all generated from run artifacts and can be traced to immutable data digests and resolved configurations.
