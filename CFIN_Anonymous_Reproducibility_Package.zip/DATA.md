# Data Provenance and Validation

## INELS

- Source page: `https://www.kaggle.com/datasets/imrandude/studentdropindia2016`
- Expected file: `studentDropIndia_20161215.csv`
- Expected records: 19,100
- Expected target field: `continue_drop`
- Expected target counts: 18,200 retained (`continue`) and 900 dropout (`drop`)
- Split: stratified 80/20 with seed 2025
- Expected training counts: 14,560 retained and 720 dropout
- Expected test counts: 3,640 retained and 180 dropout

The data loader normalizes field names, excludes identifiers, converts 59 establishment years later than 2016 to missing, and expects 338 missing values in both `total_toilets` and `establishment_year` after correction. Median imputation and missingness indicators are fitted using training data only. Normalized score fields are clipped to `[0, 1]`; the expected affected counts are 150 mathematics values, 150 science values, and 50 English values. The equality of mathematics and science marks is checked across all 19,100 records. Science marks are removed from the main analysis and retained only for the declared sensitivity analysis.

Two horizons are registered:

- `full_record`: all eligible retrospective predictors.
- `score_excluded`: eligible predictors after removing mathematics, English, and science marks.

## UCI student dropout and academic success

- Source page: `https://archive.ics.uci.edu/dataset/697/predict+students+dropout+and+academic+success`
- DOI: `10.24432/C5MC89`
- Expected records: 4,424
- Expected predictors: 36
- Expected target field: `Target`
- Expected target counts: 2,209 Graduate, 1,421 Dropout, and 794 Enrolled
- Split: stratified 80/20 with seed 2025
- Expected training counts: 1,767 Graduate, 1,137 Dropout, and 635 Enrolled
- Expected test counts: 442 Graduate, 284 Dropout, and 159 Enrolled

Three prediction horizons are registered:

- `t0_enrollment`: information available at enrollment.
- `t1_first_semester`: enrollment plus first-semester information.
- `t2_second_semester`: enrollment, first-semester, and second-semester information.

Continuous variables are standardized using training statistics for models that require scaling. Categorical fields are one-hot encoded for conventional baselines and use feature-specific embeddings in neural models. Categories absent from the training partition map to a reserved unknown value. No resampling is applied.

## Registration records

Each registration writes a JSON sidecar containing:

- retrieval or registration time in UTC;
- original source address;
- relative destination path;
- SHA-256 digest;
- record and field counts;
- target distribution;
- validation outcome.

A full run refuses to continue when a required count or target distribution differs from the registered protocol unless `--allow-data-variance` is supplied. Any variance is recorded in the resolved run configuration.
