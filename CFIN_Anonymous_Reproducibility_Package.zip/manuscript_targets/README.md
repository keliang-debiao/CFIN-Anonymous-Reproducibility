# Manuscript-Reported Targets

The CSV files in this directory transcribe the numerical values reported in the revised manuscript. They permit automated comparison after the full workflow has been executed.

These files are not generated outputs and must not be cited as execution logs. The workflow does not copy them into `results/`. Differences between generated and reported values are retained by the `cfin compare-targets` command.
