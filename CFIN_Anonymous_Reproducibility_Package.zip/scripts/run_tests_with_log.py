from __future__ import annotations

import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(ROOT / "src")
    completed = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "-rA"],
        cwd=ROOT,
        env=environment,
        capture_output=True,
        text=True,
        check=False,
    )
    lines = [
        f"{datetime.now(timezone.utc).isoformat(timespec='seconds')} | TEST_SCOPE=unit and protocol tests; full study requires registered data",
        f"python={sys.version.split()[0]}",
        completed.stdout.rstrip(),
    ]
    if completed.stderr.strip():
        lines.append(completed.stderr.rstrip())
    lines.append(f"exit_code={completed.returncode}")
    path = ROOT / "logs" / "test_run.log"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(completed.stdout, end="")
    if completed.stderr:
        print(completed.stderr, end="", file=sys.stderr)
    raise SystemExit(completed.returncode)


if __name__ == "__main__":
    main()
