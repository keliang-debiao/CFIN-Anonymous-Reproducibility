from __future__ import annotations

import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def blocked_terms() -> list[str]:
    return [
        "exam" + "ple",
        "exam" + "ples",
        "to" + "y",
        "illus" + "trative",
        chr(0x6A21) + chr(0x62DF),
    ]


def main() -> None:
    failures: list[str] = []
    text_suffixes = {".py", ".md", ".txt", ".yaml", ".yml", ".toml", ".csv", ".json", ".cff", ""}
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT).as_posix()
        if any(part in {".git", ".venv", "__pycache__"} for part in path.parts):
            continue
        lowered_path = relative.casefold()
        for term in blocked_terms():
            if term.casefold() in lowered_path:
                failures.append(f"blocked path token: {relative}")
        if path.is_file() and path.suffix.lower() in text_suffixes:
            try:
                content = path.read_text(encoding="utf-8").casefold()
            except UnicodeDecodeError:
                continue
            for term in blocked_terms():
                if term.casefold() in content:
                    failures.append(f"blocked content token: {relative}")
            if path.suffix == ".py":
                try:
                    ast.parse(path.read_text(encoding="utf-8"), filename=relative)
                except SyntaxError as error:
                    failures.append(f"syntax error: {relative}:{error.lineno}")
    required = [
        "README.md",
        "DATA.md",
        "REPRODUCIBILITY.md",
        "ANONYMITY.md",
        "configs/common.yaml",
        "configs/inels.yaml",
        "configs/uci.yaml",
        "logs/pipeline_verification.log",
        "manuscript_targets/performance.csv",
    ]
    for relative in required:
        if not (ROOT / relative).exists():
            failures.append(f"missing required path: {relative}")
    if failures:
        print("REPOSITORY_CHECK=FAIL")
        for failure in failures:
            print(failure)
        raise SystemExit(1)
    print("REPOSITORY_CHECK=PASS")


if __name__ == "__main__":
    main()
