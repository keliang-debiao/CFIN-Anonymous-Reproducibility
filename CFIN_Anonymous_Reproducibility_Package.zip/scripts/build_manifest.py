from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "MANIFEST.sha256"


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    ignored_parts = {".git", ".venv", "__pycache__", ".pytest_cache"}
    ignored_suffixes = {".pyc", ".pyo"}
    rows = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path == OUTPUT:
            continue
        if any(part in ignored_parts for part in path.parts) or path.suffix in ignored_suffixes:
            continue
        rows.append(f"{sha256(path)}  {path.relative_to(ROOT).as_posix()}")
    OUTPUT.write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"MANIFEST_ENTRIES={len(rows)}")


if __name__ == "__main__":
    main()
