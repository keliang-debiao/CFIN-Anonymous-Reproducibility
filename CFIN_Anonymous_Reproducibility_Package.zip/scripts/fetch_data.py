from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin.config import load_config
from cfin.data import clean_frame, fixed_partition, normalize_frame, validate_dataset, validate_partition_counts
from cfin.utils import sha256_file, utc_now, write_json


def fetch_uci(destination: Path) -> str:
    from ucimlrepo import fetch_ucirepo

    dataset = fetch_ucirepo(id=697)
    frame = pd.concat([dataset.data.features, dataset.data.targets], axis=1)
    frame.to_csv(destination, index=False)
    return "https://archive.ics.uci.edu/dataset/697/predict+students+dropout+and+academic+success"


def fetch_inels(destination: Path) -> str:
    import kagglehub

    downloaded = Path(kagglehub.dataset_download("imrandude/studentdropindia2016"))
    candidates = sorted(downloaded.rglob("studentDropIndia_20161215.csv"))
    if not candidates:
        candidates = sorted(downloaded.rglob("*.csv"))
    if len(candidates) != 1:
        raise RuntimeError(f"Expected one CSV, found {len(candidates)} under the retrieved directory")
    shutil.copy2(candidates[0], destination)
    return "https://www.kaggle.com/datasets/imrandude/studentdropindia2016"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["inels", "uci"], required=True)
    parser.add_argument("--allow-data-variance", action="store_true")
    args = parser.parse_args()
    config = load_config(args.dataset)
    destination = ROOT / config["dataset"]["file"]
    destination.parent.mkdir(parents=True, exist_ok=True)
    source = fetch_uci(destination) if args.dataset == "uci" else fetch_inels(destination)
    frame = normalize_frame(pd.read_csv(destination))
    cleaned = clean_frame(frame, config)
    report = validate_dataset(cleaned, config, strict=not args.allow_data_variance)
    split_report = validate_partition_counts(
        fixed_partition(cleaned, config), config, strict=not args.allow_data_variance
    )
    write_json(
        {
            "dataset": args.dataset,
            "retrieved_utc": utc_now(),
            "source": source,
            "relative_path": destination.relative_to(ROOT).as_posix(),
            "sha256": sha256_file(destination),
            "validation": report,
            "split_validation": split_report,
        },
        destination.with_suffix(".registration.json"),
    )
    print(destination)


if __name__ == "__main__":
    main()
