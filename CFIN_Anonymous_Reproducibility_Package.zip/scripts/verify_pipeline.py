from __future__ import annotations

import hashlib
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import sklearn

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin.config import load_config
from cfin.data import NeuralPreprocessor, clean_frame, fixed_partition, normalize_frame, select_horizon
from cfin.groups import field_group
from cfin.metrics import classification_metrics, select_binary_threshold
from cfin.statistics import exact_mcnemar, holm_adjust, paired_stratified_bootstrap


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_fixture() -> pd.DataFrame:
    rng = np.random.default_rng(2025)
    records = 240
    labels = np.array(["continue"] * 192 + ["drop"] * 48)
    rng.shuffle(labels)
    frame = pd.DataFrame(
        {
            "continue_drop": labels,
            "student_id": np.arange(records),
            "gender": rng.choice(["F", "M"], records),
            "caste": rng.choice(["General", "OBC", "SC", "ST"], records),
            "mathematics_marks": np.clip(rng.normal(0.62, 0.19, records), -0.1, 1.2),
            "english_marks": np.clip(rng.normal(0.58, 0.18, records), -0.1, 1.2),
            "science_marks": np.clip(rng.normal(0.62, 0.19, records), -0.1, 1.2),
            "total_students": rng.integers(80, 800, records),
            "total_toilets": rng.integers(1, 20, records).astype(float),
            "establishment_year": rng.integers(1950, 2017, records).astype(float),
            "guardian": rng.choice(["mother", "father", "other"], records),
            "internet": rng.choice(["yes", "no"], records),
        }
    )
    frame.loc[[3, 29, 81], "total_toilets"] = np.nan
    frame.loc[[9, 57], "establishment_year"] = [2020, np.nan]
    return frame


def main() -> None:
    log_path = ROOT / "logs" / "pipeline_verification.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)sZ | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
        handlers=[logging.FileHandler(log_path, mode="w", encoding="utf-8"), logging.StreamHandler()],
        force=True,
    )
    logging.Formatter.converter = __import__("time").gmtime
    logging.info("VALIDATION_SCOPE=repository pipeline only; not manuscript evidence")
    logging.info("VERSIONS python=%s numpy=%s pandas=%s sklearn=%s scipy=%s", sys.version.split()[0], np.__version__, pd.__version__, sklearn.__version__, scipy.__version__)
    for name in ("common", "inels", "uci", "tuning"):
        path = ROOT / "configs" / f"{name}.yaml"
        logging.info("CONFIG name=%s sha256=%s", name, digest(path))
    config = load_config("inels")
    frame = normalize_frame(build_fixture())
    cleaned = clean_frame(frame, config)
    assert cleaned["establishment_year"].isna().sum() == 2
    assert cleaned["mathematics_marks"].between(0.0, 1.0).all()
    partition = fixed_partition(cleaned, {**config, "dataset": {**config["dataset"], "expected_records": len(cleaned)}})
    assert len(partition.train) == 192 and len(partition.test) == 48
    train_fields = select_horizon(partition.train, config, "full_record")
    assert "science_marks" not in train_fields
    processor = NeuralPreprocessor(config).fit(train_fields)
    x_num_train, x_cat_train, numeric_names = processor.transform(train_fields)
    x_num_test, x_cat_test, _ = processor.transform(partition.test[train_fields.columns])
    assert np.isfinite(x_num_train).all() and np.isfinite(x_num_test).all()
    assert x_num_train.shape[0] == 192 and x_cat_test.shape[0] == 48
    assigned = {field: field_group(field, config) for field in train_fields.columns}
    assert set(assigned.values()).issubset(set(config["groups"]))
    score = np.linspace(0.01, 0.99, len(partition.y_test))
    grid = np.arange(0.05, 0.951, 0.01)
    threshold, validation_f1 = select_binary_threshold(partition.y_test, score, grid)
    probability = np.column_stack([1.0 - score, score])
    metrics = classification_metrics(partition.y_test, probability, partition.class_names, threshold)
    prediction_a = (score >= threshold).astype(int)
    prediction_b = (score >= 0.50).astype(int)
    mcnemar = exact_mcnemar(partition.y_test, prediction_a, prediction_b)
    bootstrap = paired_stratified_bootstrap(
        partition.y_test,
        prediction_a,
        prediction_b,
        lambda truth, prediction: float(np.mean(truth == prediction)),
        250,
        2025,
    )
    adjusted = holm_adjust([0.01, 0.04, 0.03])
    assert adjusted == sorted(adjusted)
    logging.info("SPLIT train=%d test=%d train_positive=%d test_positive=%d", len(partition.y_train), len(partition.y_test), int(partition.y_train.sum()), int(partition.y_test.sum()))
    logging.info("ENCODING numeric=%d categorical=%d groups=%s", x_num_train.shape[1], x_cat_train.shape[1], sorted(set(assigned.values())))
    logging.info("THRESHOLD selected=%.2f validation_macro_f1=%.6f", threshold, validation_f1)
    logging.info("METRICS accuracy=%.6f macro_f1=%.6f macro_auc=%.6f", metrics["accuracy"], metrics["macro_f1"], metrics["macro_ovr_auc"])
    logging.info("MCNEMAR discordant=%d raw_p=%.8f", mcnemar["a_only_correct"] + mcnemar["b_only_correct"], mcnemar["p_value"])
    logging.info("BOOTSTRAP replicates=%d difference=%.6f ci=[%.6f,%.6f] raw_p=%.8f", bootstrap["replicates"], bootstrap["difference"], bootstrap["ci_low"], bootstrap["ci_high"], bootstrap["p_value"])
    logging.info("STATUS=PASS")


if __name__ == "__main__":
    main()
