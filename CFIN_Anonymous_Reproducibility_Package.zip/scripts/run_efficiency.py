from __future__ import annotations

import json
import statistics
import sys
from collections import OrderedDict
from pathlib import Path
from time import perf_counter_ns

import joblib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin.config import load_config, load_yaml
from cfin.data import baseline_matrices, clean_frame, encode_partition, fixed_partition, read_dataset
from cfin.efficiency import benchmark_model
from cfin.model import build_neural_model


SEEDS = [11, 23, 37, 47, 59, 71, 83, 97, 109, 127]
MODELS = ["logistic_regression", "random_forest", "xgboost", "tabnet", "ft_transformer", "cfin"]


def measure_callable(function, matrix, batch_size: int, warmup: int, timed: int) -> float:
    batch = matrix[:batch_size]
    if len(batch) < batch_size:
        repeats = int(np.ceil(batch_size / len(batch)))
        batch = np.concatenate([batch] * repeats, axis=0)[:batch_size]
    for _ in range(warmup):
        function(batch)
    elapsed = []
    for _ in range(timed):
        started = perf_counter_ns()
        function(batch)
        elapsed.append((perf_counter_ns() - started) / 1_000_000.0)
    return float(statistics.median(elapsed))


def group_indices(labels: list[str]) -> OrderedDict[str, list[int]]:
    result: OrderedDict[str, list[int]] = OrderedDict()
    for index, label in enumerate(labels):
        result.setdefault(label, []).append(index)
    return result


def main() -> None:
    rows = []
    for dataset in ("inels", "uci"):
        config = load_config(dataset)
        horizon = "full_record" if dataset == "inels" else "t2_second_semester"
        partition = fixed_partition(clean_frame(read_dataset(config, ROOT), config), config)
        x_train_base, x_test_base, _ = baseline_matrices(partition, config, horizon)
        encoded = encode_partition(partition, config, horizon)
        for model_name in MODELS:
            for seed in SEEDS:
                run_dir = ROOT / "results" / "runs" / dataset / model_name / str(seed)
                with (run_dir / "metrics.json").open("r", encoding="utf-8") as handle:
                    metrics = json.load(handle)
                base = {
                    "dataset": dataset,
                    "model": model_name,
                    "seed": seed,
                    "training_seconds": metrics["training_seconds"],
                }
                if model_name in {"logistic_regression", "random_forest", "xgboost"}:
                    bundle = joblib.load(run_dir / "model.joblib")
                    predictor = bundle["model"].predict_proba
                    matrix = x_test_base
                    size_mb = (run_dir / "model.joblib").stat().st_size / (1024 * 1024)
                    for batch_size in config["efficiency"]["batch_sizes"]:
                        rows.append({**base, "batch_size": batch_size, "latency_milliseconds": measure_callable(predictor, matrix, batch_size, config["efficiency"]["warmup_passes"], config["efficiency"]["timed_passes"]), "model_size_mb": size_mb, "parameters": np.nan})
                elif model_name == "tabnet":
                    from pytorch_tabnet.tab_model import TabNetClassifier

                    matrix = x_test_base.toarray() if hasattr(x_test_base, "toarray") else x_test_base
                    predictor = TabNetClassifier(verbose=0)
                    predictor.load_model(str(run_dir / "model.zip"))
                    size_mb = (run_dir / "model.zip").stat().st_size / (1024 * 1024)
                    parameters = sum(parameter.numel() for parameter in predictor.network.parameters())
                    for batch_size in config["efficiency"]["batch_sizes"]:
                        rows.append({**base, "batch_size": batch_size, "latency_milliseconds": measure_callable(predictor.predict_proba, matrix, batch_size, config["efficiency"]["warmup_passes"], config["efficiency"]["timed_passes"]), "model_size_mb": size_mb, "parameters": parameters})
                else:
                    import torch

                    resolved = load_yaml(run_dir / "resolved_config.yaml")
                    settings = {**resolved["architecture"], **resolved["training"]}
                    model = build_neural_model(model_name, encoded.x_num_train.shape[1], encoded.category_cardinalities, group_indices(encoded.feature_groups), len(partition.class_names), settings)
                    model.load_state_dict(torch.load(run_dir / "model.pt", map_location="cpu", weights_only=True))
                    model.to(torch.device("cuda" if torch.cuda.is_available() else "cpu"))
                    size_mb = (run_dir / "model.pt").stat().st_size / (1024 * 1024)
                    for batch_size in config["efficiency"]["batch_sizes"]:
                        measured = benchmark_model(model, encoded.x_num_test, encoded.x_cat_test, batch_size, config["efficiency"]["warmup_passes"], config["efficiency"]["timed_passes"])
                        rows.append({**base, "batch_size": batch_size, "latency_milliseconds": measured["latency_milliseconds_median"], "model_size_mb": size_mb, "parameters": measured["parameters"]})
    frame = pd.DataFrame(rows)
    output = ROOT / "results" / "efficiency"
    output.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output / "per_seed_efficiency.csv", index=False)
    summary = frame.groupby(["dataset", "model", "batch_size"], as_index=False).median(numeric_only=True)
    summary.to_csv(output / "efficiency.csv", index=False)


if __name__ == "__main__":
    main()
