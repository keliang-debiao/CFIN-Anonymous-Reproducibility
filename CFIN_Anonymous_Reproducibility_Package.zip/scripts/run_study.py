from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
PYTHON = sys.executable
SEEDS = [11, 23, 37, 47, 59, 71, 83, 97, 109, 127]
DATASETS = ["inels", "uci"]
MODELS = ["logistic_regression", "random_forest", "xgboost", "tabnet", "ft_transformer", "cfin"]


def run(arguments: list[str]) -> None:
    subprocess.run(arguments, cwd=ROOT, check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["tune", "train", "horizons", "sensitivity", "ablation", "statistics", "attribution", "efficiency", "report"], required=True)
    args = parser.parse_args()
    if args.stage == "tune":
        for dataset in DATASETS:
            for model in MODELS:
                run([PYTHON, "-m", "cfin.cli", "tune", "--dataset", dataset, "--model", model])
    elif args.stage == "train":
        for dataset in DATASETS:
            for model in MODELS:
                for seed in SEEDS:
                    run([PYTHON, "-m", "cfin.cli", "run", "--dataset", dataset, "--model", model, "--seed", str(seed)])
    elif args.stage == "horizons":
        for dataset, horizons in {"inels": ["score_excluded"], "uci": ["t0_enrollment", "t1_first_semester"]}.items():
            for horizon in horizons:
                for seed in SEEDS:
                    run([PYTHON, "-m", "cfin.cli", "run", "--dataset", dataset, "--model", "cfin", "--seed", str(seed), "--horizon", horizon])
    elif args.stage == "sensitivity":
        for seed in SEEDS:
            run([PYTHON, "-m", "cfin.cli", "run", "--dataset", "inels", "--model", "cfin", "--seed", str(seed), "--horizon", "science_retained"])
    elif args.stage == "ablation":
        from cfin.ablation import CONDITIONS, aggregate_ablations, run_ablation

        for condition in CONDITIONS:
            for seed in SEEDS:
                run_ablation(condition, seed)
        aggregate_ablations()
    elif args.stage == "statistics":
        run([PYTHON, "-m", "cfin.cli", "statistics", "--replicates", "10000", "--seed", "2025"])
    elif args.stage == "attribution":
        for dataset in DATASETS:
            for seed in SEEDS:
                run([PYTHON, "-m", "cfin.cli", "attribution", "--dataset", dataset, "--seed", str(seed)])
    elif args.stage == "efficiency":
        run([PYTHON, "scripts/run_efficiency.py"])
    elif args.stage == "report":
        run([PYTHON, "-m", "cfin.cli", "report"])


if __name__ == "__main__":
    main()
