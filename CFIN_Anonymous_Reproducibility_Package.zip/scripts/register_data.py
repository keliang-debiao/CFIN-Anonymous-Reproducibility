from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin.config import load_config
from cfin.data import clean_frame, fixed_partition, normalize_frame, validate_dataset, validate_partition_counts
from cfin.utils import sha256_file, utc_now, write_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["inels", "uci"], required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--allow-data-variance", action="store_true")
    args = parser.parse_args()
    if not args.source.is_file():
        raise FileNotFoundError(args.source)
    config = load_config(args.dataset)
    destination = ROOT / config["dataset"]["file"]
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.source, destination)
    frame = normalize_frame(pd.read_csv(destination))
    cleaned = clean_frame(frame, config)
    report = validate_dataset(cleaned, config, strict=not args.allow_data_variance)
    split_report = validate_partition_counts(
        fixed_partition(cleaned, config), config, strict=not args.allow_data_variance
    )
    write_json(
        {
            "dataset": args.dataset,
            "registered_utc": utc_now(),
            "source": config["dataset"]["source"],
            "relative_path": destination.relative_to(ROOT).as_posix(),
            "sha256": sha256_file(destination),
            "validation": report,
            "split_validation": split_report,
        },
        destination.with_suffix(".registration.json"),
    )
    print(destination)


if __name__ == "__main__":
    main()
