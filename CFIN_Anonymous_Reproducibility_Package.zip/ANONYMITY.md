# Anonymous Review Checklist

The archive was prepared for double-anonymous peer review.

- Author names, affiliations, correspondence details, acknowledgements, funding statements, and contribution statements are omitted.
- Version-control metadata are omitted.
- Absolute paths and local account names are not stored.
- Data-provider citations identify public datasets but do not identify manuscript authors.
- Logs contain UTC timestamps, package versions, hardware descriptors, and relative paths only.
- Output directories do not contain source-document metadata.
- The archive can be unpacked into any directory and run without path changes.

The public release can add author and institutional information after the review process.
